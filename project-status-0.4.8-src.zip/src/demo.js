/* src/demo.js */
/* Project Status — synthetic demo data, shaped like the Flywheel API payloads the live app will read:
 *   GET /api/projects                      -> projects[]
 *   GET /api/projects/{id}/sessions        -> sessions[] (subject, satisfies_template, info.site, info.visit)
 *   GET /api/jobs?filter=parents.project=  -> jobs[] (gear_info, state, transitions, profile, origin)
 *   GET /api/projects/{id}/rules           -> rules[]
 *   GET /api/tasks/reader?filter=parents.project= -> reader tasks
 * Field names follow flywheel-sdk 23.x models where known; anything marked (verify) is an assumption.
 * Everything here is fictional: group "gne", study codes, sites, readers. */
(function () {
  'use strict';
  const DAY = 86400000, HOUR = 3600000, MIN = 60000;

  function rng(seed) { let s = seed >>> 0; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }
  const pick = (r, a) => a[Math.floor(r() * a.length)];
  const id24 = (r) => Array.from({ length: 24 }, () => '0123456789abcdef'[Math.floor(r() * 16)]).join('');

  const GEARS = {
    'dicom-mr-classifier': { version: '2.4.1', medMin: 2, fail: 0.01, reasons: ['Unrecognized series description'] },
    'dcm2niix': { version: '2.1.3_1.0.20240202', medMin: 4, fail: 0.02, reasons: ['No valid DICOM series'] },
    'totalsegmentator': { version: '2.4.0_1.2.0', medMin: 38, fail: 0.04, reasons: ['Out of memory (exit 137)', 'GPU node unavailable'] },
    'recist-pipeline': { version: '0.4.2', medMin: 12, fail: 0.03, reasons: ['Missing baseline timepoint'] },
    'oct-retina-seg': { version: '0.3.0', medMin: 9, fail: 0.03, reasons: ['Unsupported OCT vendor format'] },
    'mriqc': { version: '24.0.2_0.6.0', medMin: 26, fail: 0.02, reasons: ['BIDS curation empty'] },
    'dicom-qc': { version: '0.9.1', medMin: 3, fail: 0.01, reasons: ['Missing required tag (0018,0050)'] },
  };

  const SPECS = [
    { code: 'ONC-2201', title: 'NSCLC Phase II — BICR', indication: 'NSCLC', tier: 'Validated', criteria: 'RECIST 1.1',
      sites: ['101', '102', '104', '107', '110'], subjects: 64, weeks: 30, visits: ['Screening', 'Week 6', 'Week 12', 'Week 18', 'Week 24'], cadence: 42,
      templateMiss: 0.04, gears: ['dicom-mr-classifier', 'dcm2niix', 'totalsegmentator', 'recist-pipeline'], readsPerSession: 2, readLag: 10, readers: 4, overdue: 0.006,
      rerun: { gear: 'totalsegmentator', n: 52, fail: 0.36 }, seed: 11 },
    { code: 'ONC-2307', title: 'DLBCL Phase III — Lugano', indication: 'Lymphoma', tier: 'Validated', criteria: 'Lugano 2014',
      sites: ['201', '203', '204', '208', '211', '215'], subjects: 88, weeks: 44, visits: ['Baseline', 'Interim', 'End of Treatment', 'Follow-up 1'], cadence: 63,
      templateMiss: 0.03, gears: ['dicom-mr-classifier', 'dcm2niix', 'dicom-qc'], readsPerSession: 2, readLag: 7, readers: 5, overdue: 0.07, stalled: 0.3, seed: 23 },
    { code: 'OPH-1104', title: 'nAMD Phase II — OCT', indication: 'nAMD', tier: 'Validated', criteria: 'Central subfield thickness',
      sites: ['301', '302', '305', '306'], subjects: 52, weeks: 26, visits: ['Baseline', 'Month 1', 'Month 2', 'Month 3', 'Month 6'], cadence: 30,
      templateMiss: 0.19, staleSite: '305', gears: ['oct-retina-seg', 'dicom-qc'], readsPerSession: 1, readLag: 5, readers: 3, overdue: 0.01, seed: 37 },
    { code: 'NEU-0912', title: 'RMS Phase II — MRI', indication: 'MS', tier: 'Validated', criteria: 'New/enlarging T2',
      sites: ['401', '402', '403'], subjects: 40, weeks: 34, visits: ['Screening', 'Week 12', 'Week 24', 'Week 48'], cadence: 84,
      templateMiss: 0.02, gears: ['dicom-mr-classifier', 'dcm2niix', 'mriqc'], readsPerSession: 2, readLag: 9, readers: 3, overdue: 0, seed: 41 },
    { code: 'ONC-RWD-01', title: 'Oncology RWD — secondary use', indication: 'Pan-tumor', tier: 'Research', criteria: '—',
      sites: ['AMC-A', 'AMC-B'], subjects: 120, weeks: 20, visits: ['Imaging 1', 'Imaging 2'], cadence: 120,
      templateMiss: 0.07, gears: ['dicom-mr-classifier', 'dcm2niix', 'totalsegmentator'], readsPerSession: 0, readers: 0, seed: 53,
      pending: 7 },
    { code: 'OPH-1210', title: 'DME Phase II — start-up', indication: 'DME', tier: 'Validated', criteria: 'DRSS / CST',
      sites: ['501', '502'], subjects: 9, weeks: 3, visits: ['Screening', 'Baseline'], cadence: 14,
      templateMiss: 0.11, gears: ['oct-retina-seg', 'dicom-qc'], readsPerSession: 1, readLag: 6, readers: 2, overdue: 0, seed: 67,
      ruleDisabled: 'oct-retina-seg' },
  ];

  const READERS = ['a.okafor', 'm.lindqvist', 'r.patel', 's.moreau', 'k.tanaka', 'j.alvarez', 'e.novak', 'h.brennan'];

  function build(now) {
    const out = { group: { _id: 'gne', label: 'GNE' }, projects: [], byProject: {} };
    SPECS.forEach((sp, pi) => {
      const r = rng(sp.seed);
      const pid = id24(r);
      const start = now - sp.weeks * 7 * DAY;
      const project = {
        _id: pid, label: `${sp.code} · ${sp.title}`, group: 'gne', created: new Date(start - 14 * DAY).toISOString(),
        description: `${sp.indication}. ${sp.criteria}.`,
        info: { study_code: sp.code, indication: sp.indication, tier: sp.tier, criteria: sp.criteria }, // (verify) where tier lives
      };
      const sessions = [], jobs = [], tasks = [];
      const rules = sp.gears.map(g => ({ _id: id24(r), name: `Run ${g}`, gear_id: id24(r), _gear: g, disabled: sp.ruleDisabled === g, auto_update: false }));
      let taskSeq = 1;
      const readers = READERS.slice(pi % 3, pi % 3 + sp.readers);
      for (let s = 0; s < sp.subjects; s++) {
        const site = sp.sites[Math.floor(r() * sp.sites.length)];
        const code = `${site}-${String(s + 1).padStart(3, '0')}`;
        const enrol = start + Math.pow(r(), 0.8) * (sp.weeks * 7 - 7) * DAY;
        const subjId = id24(r);
        sp.visits.forEach((visit, vi) => {
          let t = enrol + vi * sp.cadence * DAY + (r() - 0.5) * 4 * DAY;
          if (sp.staleSite === site && t > now - 26 * DAY) return; // site stopped uploading
          if (t > now - 2 * HOUR) return;
          const sid = id24(r);
          const ok = r() > sp.templateMiss;
          const missing = ok ? [] : [pick(r, sp.indication === 'nAMD' || sp.indication === 'DME' ? ['OCT macular cube', 'Fundus photo', 'OCT angiography'] : ['Post-contrast T1', 'CT chest/abdomen', 'PET (FDG)', 'FLAIR'])];
          sessions.push({ _id: sid, label: visit, subject: { _id: subjId, code, label: code }, created: new Date(t).toISOString(), timestamp: new Date(t - 2 * DAY).toISOString(),
            satisfies_template: ok, info: { site, visit, _missing: missing } }); // (verify) satisfies_template on session list; missing-item detail
          // gear jobs launched by rules
          sp.gears.forEach((g, gi) => {
            const gd = GEARS[g]; const ov = (sp.gearOverride || {})[g] || {};
            if (sp.ruleDisabled === g && t > now - 10 * DAY) return; // rule turned off: nothing runs
            const created = t + (gi * 6 + r() * 5) * MIN;
            if (created > now) return;
            const recent = created > now - 6 * DAY;
            const failP = ov.fail != null && (!ov.recent || recent) ? ov.fail : gd.fail;
            const wait = (r() < 0.1 ? 20 + r() * 50 : 1 + r() * 6) * MIN;
            const dur = gd.medMin * (0.6 + r() * 0.9) * MIN;
            let state = r() < failP ? 'failed' : 'complete';
            if (created + wait > now) state = 'pending';
            else if (created + wait + dur > now) state = 'running';
            const job = { id: id24(r), gear_info: { name: g, version: gd.version }, state, created: new Date(created).toISOString(),
              parents: { project: pid, subject: subjId, session: sid }, origin: { type: 'rule', id: rules[gi]._id },
              transitions: {}, profile: {}, attempt: 1 };
            if (state !== 'pending') job.transitions.running = new Date(created + wait).toISOString();
            if (state === 'complete' || state === 'failed') {
              job.transitions[state] = new Date(created + wait + dur).toISOString();
              job.profile.elapsed_time_ms = Math.round(dur); // (verify) field name
            }
            if (state === 'failed') job.failure_reason = pick(r, gd.reasons); // (verify) exposed on job list
            jobs.push(job);
            if (state === 'failed' && r() < 0.4 && created + wait + dur + 2 * HOUR < now) { // a retry that succeeded
              jobs.push({ ...job, id: id24(r), state: 'complete', attempt: 2, failure_reason: undefined, created: new Date(created + wait + dur + HOUR).toISOString(),
                transitions: { running: new Date(created + wait + dur + HOUR + 3 * MIN).toISOString(), complete: new Date(created + wait + dur + HOUR + 3 * MIN + dur).toISOString() },
                origin: { type: 'user', id: 'dm@gne.example' } });
            }
          });
          // reader tasks
          if (sp.readsPerSession && ok && t < now - 1 * DAY) {
            const tasked = r() > (t > now - 5 * DAY ? 0.6 : 0.04);
            if (!tasked) return;
            const tcreated0 = t + (0.5 + r() * 1.5) * DAY;
            const due0 = tcreated0 + sp.readLag * DAY;
            const tcreated = tcreated0, due = due0;
            const pool = readers.slice().sort(() => r() - 0.5);
            for (let k = 0; k < sp.readsPerSession; k++) {
              let tcreated = tcreated0, due = due0;
              const age = (now - tcreated) / DAY;
              let status;
              const lateP = sp.overdue || 0;
              if (now > due) status = r() < lateP ? pick(r, ['todo', 'in_progress', 'in_progress']) : 'completed';
              else status = age > sp.readLag * 0.6 ? pick(r, ['completed', 'completed', 'in_progress', 'todo']) : pick(r, ['todo', 'in_progress', 'completed']);
              if (status !== 'completed' && now > due) { due = now - (1 + Math.floor(r() * 16)) * DAY; tcreated = due - sp.readLag * DAY; } // late reads are recent, not months old
              const stalled = status === 'in_progress' && r() < (sp.stalled || 0.05);
              const modified = status === 'completed' ? Math.min(now - HOUR, tcreated + (1 + r() * (sp.readLag - 1)) * DAY)
                : stalled ? tcreated + 0.5 * DAY : Math.min(now - HOUR, tcreated + r() * age * DAY);
              const transitions = { todo: new Date(tcreated).toISOString() };
              if (status !== 'todo') transitions.in_progress = new Date(tcreated + 0.2 * DAY).toISOString();
              if (status === 'completed') transitions.completed = new Date(modified).toISOString();
              tasks.push({ _id: id24(r), task_id: `R-${sp.code.split('-')[1]}-${String(taskSeq).padStart(4, '0')}-${k + 1}`, status, priority: 'medium', subcategory: 'reader',
                protocol_label: `${sp.criteria} read`, assignee: { type: 'user', id: `${pool[k % pool.length]}@reader.example` }, read_number: k + 1,
                parents: { project: pid, subject: subjId, session: sid }, created: new Date(tcreated).toISOString(), modified: new Date(modified).toISOString(),
                due_date: new Date(due).toISOString().slice(0, 10), transitions });
            }
            if (sp.readsPerSession > 1 && r() < 0.08) {
              tasks.push({ _id: id24(r), task_id: `R-${sp.code.split('-')[1]}-${String(taskSeq).padStart(4, '0')}-A`, status: r() < 0.5 ? 'blocked' : 'todo', priority: 'high',
                subcategory: 'adjudicator', protocol_label: `${sp.criteria} adjudication`, assignee: null, parents: { project: pid, subject: subjId, session: sid },
                created: new Date(tcreated).toISOString(), modified: new Date(tcreated).toISOString(), due_date: new Date(due + 5 * DAY).toISOString().slice(0, 10), transitions: {} });
            }
            taskSeq++;
          }
        });
      }
      // a re-run after a gear version bump (ONC-2201): many recent runs, many out-of-memory failures
      if (sp.rerun) {
        const g = sp.rerun.gear, gd = GEARS[g];
        const pool = sessions.filter(x => x.satisfies_template).slice(-sp.rerun.n);
        pool.forEach((x, k) => {
          const created = now - (5.5 - (k / pool.length) * 5) * DAY;
          const dur = gd.medMin * (0.7 + r() * 0.8) * MIN, wait = (2 + r() * 8) * MIN;
          const failed = r() < sp.rerun.fail;
          const j = { id: id24(r), gear_info: { name: g, version: '2.5.0_1.3.0' }, state: failed ? 'failed' : 'complete', created: new Date(created).toISOString(),
            parents: { project: pid, subject: x.subject._id, session: x._id }, origin: { type: 'user', id: 'cm@gne.example' }, attempt: 1,
            transitions: { running: new Date(created + wait).toISOString() }, profile: { elapsed_time_ms: Math.round(dur) } };
          j.transitions[j.state] = new Date(created + wait + dur).toISOString();
          if (failed) j.failure_reason = r() < 0.85 ? 'Out of memory (exit 137)' : 'GPU node unavailable';
          jobs.push(j);
        });
      }
      // queue backlog on the research project
      for (let k = 0; k < (sp.pending || 0); k++) {
        const created = now - (70 + r() * 90) * MIN;
        jobs.push({ id: id24(r), gear_info: { name: 'totalsegmentator', version: GEARS.totalsegmentator.version }, state: 'pending', created: new Date(created).toISOString(),
          parents: { project: pid, session: sessions[sessions.length - 1 - k]._id }, origin: { type: 'user', id: 'ds@gne.example' }, transitions: {}, profile: {}, attempt: 1 });
      }
      const statistics = { subjects: new Set(sessions.map(x => x.subject._id)).size, sessions: sessions.length,
        acquisitions: Math.round(sessions.length * 1.08), acquisition_files: Math.round(sessions.length * 1.08 * 8.3),
        analyses: jobs.filter(j => j.state === 'complete').length, jobs: jobs.length };
      // access log rows (aggregated like GET /api/report/accesslog; subject fields omitted)
      const access = [];
      const people = ['dm@gne.example', 'cm@gne.example', 'ds@gne.example', 'qa@gne.example', 'r.lee@cro.example'].slice(0, 2 + Math.floor(r() * 4));
      const idle = sp.code === 'NEU-0912' ? 41 : 0;
      for (let d = 0; d < 70; d++) {
        if (d < idle) continue;
        const at = now - (d + r() * 0.9) * DAY, iso = new Date(at).toISOString();
        people.forEach(u => {
          if (r() < 0.55) access.push({ access_type: 'view_container', count: 2 + Math.floor(r() * 30), first_access: iso, last_access: iso, origin: { type: 'user', id: u } });
          if (r() < 0.35) { const spike = sp.code === 'ONC-2201' && d < 6 && u === people[1]; access.push({ access_type: 'download_file', count: spike ? 900 + Math.floor(r() * 600) : 5 + Math.floor(r() * 40), first_access: iso, last_access: iso, origin: { type: 'user', id: u } }); }
        });
      }
      if (sp.code === 'OPH-1104') access.push({ access_type: 'delete_file', count: 6, first_access: new Date(now - 2 * DAY).toISOString(), last_access: new Date(now - 2 * DAY).toISOString(), origin: { type: 'user', id: people[0] } },
        { access_type: 'replace_file', count: 3, first_access: new Date(now - 4 * DAY).toISOString(), last_access: new Date(now - 4 * DAY).toISOString(), origin: { type: 'user', id: people[0] } });
      if (sp.code === 'OPH-1210') access.push({ access_type: 'add_permission', count: 2, first_access: new Date(now - 1 * DAY).toISOString(), last_access: new Date(now - 1 * DAY).toISOString(), origin: { type: 'user', id: 'admin@gne.example' } });
      out.projects.push(project);
      out.byProject[pid] = { project, statistics, sessions, jobs, rules, tasks, access, snapshotAgeMin: 3 + Math.floor(r() * 11), // micro-batch target: every 15 min
        spec: { readsPerSession: sp.readsPerSession, gears: sp.gears } };
    });
    return out;
  }

  /* One project at real-project scale, emitted directly as a facts document (what the snapshot gear would write).
   * Magnitudes follow a real GNE production project Dan shared on 2026-11-20 (~165k sessions, ~5.9M jobs);
   * every name and number here is fictional. */
  function scaleFacts(now) {
    const r = rng(9100);
    const W = 26;
    const sessions = 162310, templateOk = 153708;
    const siteN = 214;
    const raw = Array.from({ length: siteN }, (_, i) => 1 / Math.pow(i + 1, 0.55));
    const sum = raw.reduce((a, b) => a + b, 0);
    const sites = raw.map((w, i) => {
      const n = Math.max(12, Math.round((w / sum) * sessions));
      let share = Math.min(1, 0.955 + (r() - 0.5) * 0.07);
      if (i === 7 || i === 41) share = 0.79 + r() * 0.04;
      let idle = r() * 3;
      if (i === 63 || i === 118 || i === 170) idle = 25 + r() * 40;
      const code = String(1000 + i * 7);
      return { site: code, subjects: Math.max(2, Math.round(n / 9)), sessions: n, template_ok: Math.round(n * share), last: now - idle * DAY - r() * 6 * HOUR };
    });
    const weekly = [];
    for (let i = W - 1; i >= 0; i--) { const d = new Date(now - i * 7 * DAY); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); weekly.push({ week: d.getTime(), n: Math.round(1050 + Math.sin(i / 3) * 180 + r() * 220) }); }
    weekly[weekly.length - 1].n = Math.round(weekly[weekly.length - 1].n * 0.55); // current partial week
    const visits = ['Screening', 'Baseline', 'Week 8', 'Week 16', 'Week 24', 'Week 48', 'Week 96'];
    const missingItems = ['Post-contrast T1', 'CT chest/abdomen', 'OCT macular cube', 'PET (FDG)', 'Fundus photo'];
    const missing = Array.from({ length: 50 }, (_, i) => { const st = sites[Math.floor(r() * 60)]; return { id: id24(r), subject: `${st.site}-${String(1 + Math.floor(r() * 400)).padStart(4, '0')}`,
      visit: pick(r, visits), site: st.site, created: now - (i * 0.4 + r() * 0.4) * DAY, missing: pick(r, missingItems) }; });
    const readers = Array.from({ length: 26 }, (_, i) => { const total = 1200 + Math.floor(r() * 1400); const open = 20 + Math.floor(r() * 60);
      return { reader: `reader-${String(i + 1).padStart(2, '0')}`, total, completed: total - open, open, overdue: i < 6 ? 2 + Math.floor(r() * 6) : Math.floor(r() * 2), stalled: Math.floor(r() * 2), turnaround_days: 1.4 + r() * 3 }; })
      .sort((a, b) => b.open - a.open);
    const overdueTotal = readers.reduce((a, x) => a + x.overdue, 0);
    const overdue = Array.from({ length: Math.min(50, overdueTotal) }, (_, i) => { const due = now - (1 + Math.floor((overdueTotal - i) / 2.2)) * DAY;
      return { id: id24(r), task_id: `R-9100-${String(40000 + i * 13).padStart(5, '0')}-${1 + (i % 2)}`, status: pick(r, ['todo', 'in_progress']), due, created: due - 10 * DAY,
        overdue: true, overdueDays: Math.floor((now - due) / DAY), stalled: false, ageDays: (now - due) / DAY + 10, reader: readers[i % 6].reader, assigned: true }; })
      .sort((a, b) => b.overdueDays - a.overdueDays);
    const gearSpec = [
      ['dicom-mr-classifier', '2.4.1', 9400, 0.004, 2, 'Unrecognized series description'],
      ['dcm2niix', '2.1.3_1.0.20240202', 9300, 0.011, 4, 'No valid DICOM series'],
      ['dicom-qc', '0.9.1', 9350, 0.006, 3, 'Missing required tag (0018,0050)'],
      ['totalsegmentator', '2.5.0_1.3.0', 4100, 0.021, 41, 'GPU node unavailable'],
      ['recist-pipeline', '0.4.2', 2900, 0.018, 12, 'Missing baseline timepoint'],
      ['oct-retina-seg', '0.3.0', 2600, 0.012, 9, 'Unsupported OCT vendor format'],
      ['mriqc', '24.0.2_0.6.0', 1900, 0.092, 27, 'BIDS curation empty'],
      ['file-metadata-importer', '1.5.4', 1700, 0.003, 1, 'Unreadable header'],
      ['deid-export', '1.8.0', 450, 0.0, 6, '—'],
    ];
    const gears = gearSpec.map(([gear, version, runs, fail, med, reason]) => { const finished = Math.round(runs * 0.985); const failed = Math.round(finished * fail);
      return { gear, versions: [{ version, runs }], last_version: version, runs, finished, failed, median_min: med * (0.9 + r() * 0.2),
        reasons: failed ? [{ reason, n: failed }] : [], rule: 'on' }; });
    const jobsWindow = gears.reduce((a, g) => a + g.runs, 0), finished = gears.reduce((a, g) => a + g.finished, 0), failed = gears.reduce((a, g) => a + g.failed, 0);
    const daily = [];
    for (let i = 13; i >= 0; i--) { const d = new Date(now - i * DAY); d.setHours(0, 0, 0, 0); const part = i === 0 ? 0.55 : 1; daily.push({ day: d.getTime(), complete: Math.round((5600 + r() * 900) * part), failed: Math.round((110 + r() * 110) * part) }); }
    const pending = Array.from({ length: 50 }, (_, i) => ({ id: id24(r), gear: pick(r, ['totalsegmentator', 'mriqc', 'recist-pipeline']), version: '', launched_by: r() < 0.8 ? 'Gear rule' : 'cm@gne.example', wait_min: 212 - i * 2.6 - r() * 2 }));
    pending.forEach(p => { p.version = gearSpec.find(g => g[0] === p.gear)[1]; });
    const unresolved = Array.from({ length: 50 }, (_, i) => { const g = pick(r, gears.filter(x => x.failed)); return { id: id24(r), gear: g.gear, version: g.last_version, reason: g.reasons[0].reason, launched_by: 'Gear rule', at: now - (i * 0.3 + r() * 0.3) * HOUR * 6 }; });
    return {
      schema: 'project-status/facts@1', generated_at: now - 9 * MIN, window_days: 7,
      project: { _id: '6f00a1c2e4b5d6a7b8c9d0e1', label: 'ONC-9100 · Pan-tumor imaging archive', info: { study_code: 'ONC-9100', indication: 'Pan-tumor', tier: 'Validated', criteria: 'RECIST 1.1 / iRECIST', scale_demo: true } },
      statistics: { subjects: 17950, sessions, acquisitions: 175880, acquisition_files: 1462905, analyses: 17964, jobs: 5871204 },
      data: { subjects: 17950, sessions, template_ok: templateOk, last: now - 38 * MIN, recent: 2140, sites, sites_total: siteN, missing, missing_total: sessions - templateOk, weekly },
      tasks: { used: true, total: readers.reduce((a, x) => a + x.total, 0), completed: readers.reduce((a, x) => a + x.completed, 0), open: readers.reduce((a, x) => a + x.open, 0),
        overdue, overdue_total: overdueTotal, stalled_total: readers.reduce((a, x) => a + x.stalled, 0), unassigned: 38, readers, readers_total: readers.length,
        weekly: Array.from({ length: 11 }, (_, i) => ({ week: weekly[W - 12 + i].week, n: Math.round(640 + r() * 220) })),
        age: [{ bucket: '0–7 d', n: 1180 }, { bucket: '8–14 d', n: 214 }, { bucket: '15–30 d', n: 31 }, { bucket: '> 30 d', n: 6 }], adj_open: 85, adj_blocked: 61 },
      compute: { jobs_window: jobsWindow, finished, failed, running: 64, pending, pending_total: 1840, queue_p95_min: 96, queue_max_min: 212, median_wait_min: 6.5,
        hours: 9850, gears, daily, unresolved, unresolved_total: 3412, rules: gears.map(g => ({ name: `Run ${g.gear}`, gear: g.gear, disabled: false })) },
      activity: { available: true, last: now - 4 * MIN, users_7d: 38, users_30d: 61, downloads_7d: 48210, downloads_30d: 171400, downloads_baseline: 41200,
        downloads_weekly: weekly.slice(-12).map((w, i) => ({ week: w.week, n: Math.round(36000 + r() * 9000 + (i === 11 ? -18000 : 0)) })),
        top_downloaders: [['ds-pipeline@gne.example', 52100], ['a.kim@gne.example', 18400], ['r.lee@cro.example', 9900], ['qa@gne.example', 4100]].map(([user, n], i) => ({ user, n, last: now - (i + 1) * HOUR })), downloaders_total: 44,
        changes: [{ type: 'replace_file', user: 'dm@gne.example', n: 212, last: now - 3 * HOUR }, { type: 'delete_file', user: 'dm@gne.example', n: 37, last: now - 26 * HOUR }, { type: 'sync_to_external', user: 'ds-pipeline@gne.example', n: 4, last: now - 2 * DAY }], changes_total: 253, changes_7d: 61,
        access_changes: [{ type: 'add_permission', user: 'admin@gne.example', n: 3, last: now - 5 * DAY }], access_changes_7d: 3 },
      pipeline: { uploaded: sessions, template: templateOk, processed: 149920, tasked: 141300, read: 139880, reads: true,
        flow: [['dicom-mr-classifier', 161200, 610, 220, 0, 0], ['dcm2niix', 158900, 1480, 300, 4, 1], ['totalsegmentator', 151300, 5200, 1640, 31, 2], ['recist-pipeline', 149920, 2780, 1250, 52, 3], ['mriqc', 0, 0, 0, 0, null, 'disabled']]
          .map(([gear, complete, failed, running, x, order, st]) => ({ gear, rules: [`Run ${gear}`], disabled: st === 'disabled', sessions, complete, failed, running, none: sessions - complete - failed - running, order, state: st || 'enabled' })) },
    };
  }

  /* LIVE DELTA: what the app would count at page load with created>{generated_at} filters (verify the filter exists).
   * Small studies: computed from the raw demo records. Scale project: synthetic. */
  function liveDelta(rec, since, now) {
    const t = v => Date.parse(v);
    const fin = j => t(j.transitions && (j.transitions.failed || j.transitions.complete) || j.created);
    const failures = rec.jobs.filter(j => j.state === 'failed' && fin(j) > since).sort((a, b) => fin(b) - fin(a));
    return { fetched_at: now, since,
      sessions_new: rec.sessions.filter(x => t(x.created) > since).length,
      jobs_new: rec.jobs.filter(j => t(j.created) > since).length,
      failed_new: failures.length,
      failures: failures.slice(0, 5).map(j => ({ id: j.id, gear: j.gear_info.name, version: j.gear_info.version, reason: j.failure_reason || null, at: fin(j) })),
      reads_completed_new: rec.tasks.filter(x => x.status === 'completed' && t(x.transitions && x.transitions.completed) > since).length };
  }
  function scaleLive(f, now) {
    const r = rng(77); const since = f.generated_at;
    const reasons = [['totalsegmentator', '2.5.0_1.3.0', 'GPU node unavailable'], ['mriqc', '24.0.2_0.6.0', 'BIDS curation empty'], ['dcm2niix', '2.1.3_1.0.20240202', 'No valid DICOM series']];
    return { fetched_at: now, since, sessions_new: 14, jobs_new: 612, failed_new: 9, reads_completed_new: 41,
      failures: Array.from({ length: 5 }, (_, i) => { const g = reasons[Math.floor(r() * reasons.length)]; return { id: id24(r), gear: g[0], version: g[1], reason: g[2], at: now - (i * 1.6 + r()) * MIN }; }) };
  }

  window.PSD_DEMO = { build, scaleFacts, liveDelta, scaleLive, GEARS };
  window.PSD_LIVE_DELTA = liveDelta;
})();
