/* src/app.js */
/* Project Status — Flywheel custom app (prototype, demo data).
 * One shared view of project health for three personas: data manager, task manager, compute manager.
 * Built on the Flywheel Vision Design System React bundle (window.FlywheelVisionDesignSystem_6c883d). Read-only. */
(function () {
  'use strict';
  const BUILD = window.PSD_BUILD || { app: 'project-status', version: '0.4.7', mode: 'prototype', built: null };
  const V = window.FlywheelVisionDesignSystem_6c883d;
  const { Button, IconButton, Typography, Tag, Tabs, Tab, TabPanel, Select, SelectItem, Table, PanelLayout, AlertPanel, ContextLayout, ProgressBar, Icon } = V;
  const PSD_LIVE = window.PSD_LIVE;
  const PSDL = window.PSD;
  const { useState, useEffect, useMemo, useRef } = React;
  const h = React.createElement;
  const DAY = 86400000;

  const store = {
    get(k) { try { return window.localStorage.getItem(k); } catch (e) { return null; } },
    set(k, v) { try { window.localStorage.setItem(k, v); } catch (e) { /* storage blocked */ } },
  };
  // one decimal so a share never rounds across a threshold (94.7% must not read as 95%)
  const fmtPct = v => (v == null ? '—' : `${(Math.round(v * 1000) / 10).toLocaleString(undefined, { maximumFractionDigits: 1 })}%`);
  const fmtNum = v => (v == null ? '—' : Number(v).toLocaleString());
  const fmtDay = t => (!t ? '—' : new Date(t).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }));
  const fmtAgo = (t, now) => { if (!t) return '—'; const d = (now - t) / DAY; return d < 1 / 24 ? `${Math.max(1, Math.round(d * 1440))} min ago` : d < 1 ? `${Math.round(d * 24)} h ago` : `${Math.floor(d)} d ago`; };
  const fmtMin = v => (v == null ? '—' : v < 60 ? `${Math.round(v)} min` : `${(v / 60).toFixed(1)} h`);

  const LENS = {
    data: { label: 'Data', persona: 'Data manager', icon: 'server-databases-sync-import', color: 'primary' },
    tasks: { label: 'Tasks', persona: 'Task manager', icon: 'checklist-tasks-chechmark-square', color: 'secondary' },
    compute: { label: 'Compute', persona: 'Compute manager', icon: 'computer-chip', color: 'slate' },
  };
  const HEALTH = {
    act: { label: 'Action', color: 'red', icon: 'warning-circle' },
    watch: { label: 'Watch', color: 'orange', icon: 'warning' },
    ok: { label: 'On track', color: 'green', icon: 'done-check' },
    na: { label: 'Not used', color: 'slate', icon: 'minus' },
    info: { label: 'FYI', color: 'slate', icon: 'information-circle' },
    off: { label: 'Unavailable', color: 'slate', icon: 'lock' },
  };
  const HealthTag = ({ h: k, size }) => h(Tag, { color: HEALTH[k].color, icon: HEALTH[k].icon, title: HEALTH[k].label, size: size || 'small' });

  // ------------------------------------------------------------ routing (#projects, #p-<id>-<tab>; plain #names only)
  function parseHash() {
    const m = /^#p-([0-9a-f]+)(?:-(\w+))?$/.exec(location.hash || '');
    return m ? { view: 'project', pid: m[1], tab: m[2] || 'overview' } : { view: 'portfolio' };
  }
  function useRoute() {
    const [r, setR] = useState(parseHash());
    useEffect(() => { const f = () => setR(parseHash()); window.addEventListener('hashchange', f); return () => window.removeEventListener('hashchange', f); }, []);
    return r;
  }
  const go = (hash) => { if (location.hash !== hash) location.hash = hash; window.scrollTo(0, 0); };

  // ------------------------------------------------------------ charts (hand-built SVG on Vision tokens)
  function useWidth(ref, fallback) {
    const [w, setW] = useState(fallback);
    useEffect(() => {
      if (!ref.current) return;
      const ro = new ResizeObserver(es => { for (const e of es) setW(Math.max(240, Math.floor(e.contentRect.width))); });
      ro.observe(ref.current);
      return () => ro.disconnect();
    }, []);
    return w;
  }
  const axisText = { fontSize: 11, fill: 'var(--typography-light)', fontFamily: 'var(--font-sans)' };
  const labelText = { fontSize: 12, fill: 'var(--typography-muted)', fontFamily: 'var(--font-sans)' };
  const fmtAxis = v => (v >= 1000 ? `${+(v / 1000).toFixed(1)}k` : String(Math.round(v)));
  function niceMax(v) { if (v <= 5) return 5; const p = Math.pow(10, Math.floor(Math.log10(v))); for (const m of [1, 2, 5, 10]) if (m * p >= v) return m * p; return 10 * p; }
  function Legend({ items }) {
    return h('div', { className: 'psd-legend', role: 'list' }, items.map(([label, color]) => h('span', { key: label, role: 'listitem' }, h('i', { style: { background: color } }), label)));
  }

  function WeeklyBars({ points, label, color }) {
    const ref = useRef(null); const w = useWidth(ref, 520);
    const H = 200, left = 34, right = 8, top = 16, bottom = 24;
    const max = niceMax(Math.max(1, ...points.map(p => p.n)));
    const pw = w - left - right, ph = H - top - bottom, bw = pw / Math.max(1, points.length);
    const y = v => top + ph - (v / max) * ph;
    const every = Math.max(1, Math.ceil(points.length / Math.max(2, Math.floor(pw / 64))));
    return h('div', { ref, className: 'psd-chart' },
      h('svg', { width: w, height: H, role: 'img', 'aria-label': label },
        [0, 0.5, 1].map(f => h('g', { key: f },
          h('line', { x1: left, x2: w - right, y1: y(f * max), y2: y(f * max), stroke: 'var(--separations-base)' }),
          h('text', { x: left - 6, y: y(f * max) + 4, textAnchor: 'end', style: axisText }, fmtAxis(f * max)))),
        points.map((p, i) => {
          const x0 = left + i * bw + bw * 0.2, wd = bw * 0.6;
          return h('g', { key: p.week },
            h('rect', { x: x0, y: y(p.n), width: wd, height: Math.max(0, y(0) - y(p.n)), rx: 3, fill: color || 'var(--primary-base)' }, h('title', null, `Week of ${fmtDay(p.week)}: ${p.n}`)),
            i % every === 0 ? h('text', { x: x0 + wd / 2, y: H - 6, textAnchor: 'middle', style: axisText }, fmtDay(p.week)) : null);
        })));
  }

  function AgeBars({ data }) {
    const ref = useRef(null); const w = useWidth(ref, 520);
    const H = 200, left = 34, right = 8, top = 18, bottom = 24;
    const max = niceMax(Math.max(1, ...data.map(d => d.n)));
    const pw = w - left - right, ph = H - top - bottom, bw = pw / Math.max(1, data.length);
    const y = v => top + ph - (v / max) * ph;
    return h('div', { ref, className: 'psd-chart' },
      h('svg', { width: w, height: H, role: 'img', 'aria-label': 'Open reads by days since the task was created' },
        [0, 0.5, 1].map(f => h('g', { key: f },
          h('line', { x1: left, x2: w - right, y1: y(f * max), y2: y(f * max), stroke: 'var(--separations-base)' }),
          h('text', { x: left - 6, y: y(f * max) + 4, textAnchor: 'end', style: axisText }, fmtAxis(f * max)))),
        data.map((d, i) => {
          const x0 = left + i * bw + bw * 0.2, wd = bw * 0.6, late = i >= data.length - 2;
          return h('g', { key: d.bucket },
            h('rect', { x: x0, y: y(d.n), width: wd, height: Math.max(0, y(0) - y(d.n)), rx: 4, fill: late ? 'var(--orange-base)' : 'var(--secondary-base)' }, h('title', null, `${d.bucket}: ${d.n} open reads`)),
            h('text', { x: x0 + wd / 2, y: y(d.n) - 5, textAnchor: 'middle', style: { ...labelText, fontWeight: 500 } }, d.n),
            h('text', { x: x0 + wd / 2, y: H - 6, textAnchor: 'middle', style: axisText }, d.bucket));
        })));
  }

  function DailyJobs({ days }) {
    const ref = useRef(null); const w = useWidth(ref, 520);
    const H = 200, left = 34, right = 8, top = 12, bottom = 24;
    const max = niceMax(Math.max(1, ...days.map(d => d.complete + d.failed)));
    const pw = w - left - right, ph = H - top - bottom, bw = pw / Math.max(1, days.length);
    const y = v => top + ph - (v / max) * ph;
    const every = Math.max(1, Math.ceil(days.length / Math.max(2, Math.floor(pw / 56))));
    return h('div', { ref, className: 'psd-chart' },
      h('svg', { width: w, height: H, role: 'img', 'aria-label': 'Finished jobs per day, complete and failed' },
        [0, 0.5, 1].map(f => h('g', { key: f },
          h('line', { x1: left, x2: w - right, y1: y(f * max), y2: y(f * max), stroke: 'var(--separations-base)' }),
          h('text', { x: left - 6, y: y(f * max) + 4, textAnchor: 'end', style: axisText }, fmtAxis(f * max)))),
        days.map((d, i) => {
          const x0 = left + i * bw + bw * 0.18, wd = bw * 0.64;
          const yc = y(d.complete), yf = y(d.complete + d.failed);
          return h('g', { key: d.day },
            h('title', null, `${fmtDay(d.day)}: ${d.complete} complete, ${d.failed} failed`),
            h('rect', { x: x0, y: yc, width: wd, height: Math.max(0, y(0) - yc), rx: 2, fill: 'var(--slate-base)' }),
            d.failed ? h('rect', { x: x0, y: yf, width: wd, height: Math.max(1, yc - yf - 1), rx: 2, fill: 'var(--red-base)' }) : null,
            i % every === 0 ? h('text', { x: x0 + wd / 2, y: H - 6, textAnchor: 'middle', style: axisText }, fmtDay(d.day)) : null);
        })),
      h(Legend, { items: [['Complete', 'var(--slate-base)'], ['Failed', 'var(--red-base)']] }));
  }

  const FLOW_SEG = [['complete', 'Complete', 'var(--green-base)'], ['failed', 'Failed or cancelled', 'var(--red-base)'], ['running', 'Running or queued', 'var(--orange-base)']];
  function RuleFlow({ flow }) {
    if (!flow || !flow.length) return h('div', { className: 'psd-empty' }, 'No gear rules on this project.');
    const stateTag = n => n.state === 'disabled' ? h(Tag, { size: 'small', color: 'orange', title: 'Rule disabled' })
      : n.state === 'never_ran' ? h(Tag, { size: 'small', color: 'red', title: 'Never ran' }) : h(Tag, { size: 'small', color: 'slate', title: 'Rule enabled' });
    return h('div', null,
      h('div', { className: 'psd-flow' }, flow.map((n, i) => h(React.Fragment, { key: n.gear },
        i > 0 && h('span', { className: 'psd-flow-arrow', 'aria-hidden': true }, h(Icon, { name: 'chevron-forward', size: 'small', color: 'light', decorative: true })),
        h('div', { className: 'psd-flow-node' + (n.state === 'disabled' ? ' off' : '') + (n.state === 'never_ran' ? ' bad' : ''),
          title: `${n.gear}\nRules: ${n.rules.join(', ')}\nComplete ${n.complete} · failed ${n.failed} · running ${n.running} · no job ${n.none} (of ${n.sessions} sessions)` + (n.order != null ? `\nUsually step ${n.order + 1} by latest run per session (approximate)` : '') },
          h('div', { className: 'psd-flow-head' }, n.missing_gear ? h('span', { className: 'psd-strong' }, n.label) : h('code', null, n.gear), stateTag(n)),
          n.missing_gear && h('div', { className: 'psd-flow-sub' }, 'Gear not installed on this site'),
          h('div', { className: 'psd-flow-bar', role: 'img', 'aria-label': `${n.complete} of ${n.sessions} sessions complete` },
            FLOW_SEG.map(([k, , col]) => n[k] ? h('span', { key: k, style: { width: `${(n[k] / Math.max(1, n.sessions)) * 100}%`, background: col } }) : null)),
          h('div', { className: 'psd-flow-n' }, h('b', null, fmtNum(n.complete)), ` of ${fmtNum(n.sessions)} complete`),
          h('div', { className: 'psd-flow-sub' }, [n.failed && `${fmtNum(n.failed)} failed`, n.running && `${fmtNum(n.running)} running`, n.none && `${fmtNum(n.none)} no job`].filter(Boolean).join(' · ') || 'All sessions complete'))))),
      h(Legend, { items: [...FLOW_SEG.map(([, l, c]) => [l, c]), ['No job', 'var(--slate-hover)']] }));
  }

  const CHANGE_LABEL = { delete_file: 'File deleted', delete_container: 'Container deleted', delete_analysis: 'Analysis deleted', delete_annotation: 'Annotation deleted',
    delete_form_response: 'Form response deleted', replace_file: 'File replaced', file_moved_away: 'File moved out', file_moved_in: 'File moved in',
    container_moved_away: 'Container moved out', container_moved_in: 'Container moved in', sync_to_external: 'Synced to external storage',
    add_permission: 'Permission added', modify_permission: 'Permission changed', role_change: 'Role changed', user_role_change: 'User role changed' };
  function ActivitySection({ act, now }) {
    if (!act) return null;
    if (!act.available) return h(Panel, { title: 'Activity', wide: true },
      h(AlertPanel, { severity: 'info', icon: 'lock', title: 'Unavailable with this access', description: 'Activity comes from the site Access Log, which your account cannot read from this app. The snapshot job will provide these counts.' }));
    const evCols = [
      { key: 'type', header: 'What', render: r => CHANGE_LABEL[r.type] || r.type },
      { key: 'user', header: 'By', render: r => h('span', { className: 'psd-strong' }, r.user) },
      { key: 'n', header: 'Events', align: 'right', render: r => fmtNum(r.n) },
      { key: 'last', header: 'Last', align: 'right', render: r => fmtAgo(r.last, now) },
    ];
    const dlCols = [
      { key: 'user', header: 'User', render: r => h('span', { className: 'psd-strong' }, r.user) },
      { key: 'n', header: 'Downloads, 30 d', align: 'right', render: r => fmtNum(r.n) },
      { key: 'last', header: 'Last', align: 'right', render: r => fmtAgo(r.last, now) },
    ];
    const events = [...act.changes, ...act.access_changes].sort((a, b) => b.last - a.last);
    return h('div', { className: 'psd-stack' },
      h('div', { className: 'psd-kpis' },
        h(Kpi, { label: 'Last user activity', value: act.last ? fmtAgo(act.last, now) : 'None', src: 'snap' }),
        h(Kpi, { label: 'Active users, 7 d', value: fmtNum(act.users_7d), sub: `${fmtNum(act.users_30d)} in 30 d`, src: 'snap' }),
        h(Kpi, { label: 'Downloads, 7 d', value: fmtNum(act.downloads_7d), sub: `usual week ≈ ${fmtNum(Math.round(act.downloads_baseline))}`, tone: act.downloads_7d >= 100 && act.downloads_7d > 3 * Math.max(1, act.downloads_baseline) ? 'warn' : null, src: 'snap' }),
        h(Kpi, { label: 'Data changes, 30 d', value: fmtNum(act.changes_total), sub: 'deletes, replaces, moves, syncs', tone: act.changes_7d ? 'warn' : null, src: 'snap' })),
      h('div', { className: 'psd-grid two' },
        h(Panel, { title: 'Downloads per week', sub: 'File downloads (Access Log), dated by last access', right: h(SrcMark, { src: 'snap' }) }, h(WeeklyBars, { points: act.downloads_weekly, label: 'Downloads per week', color: 'var(--secondary-base)' })),
        h(Panel, { title: 'Top downloaders', sub: 'Last 30 days', right: h(Tag, { color: 'slate', title: fmtNum(act.downloaders_total) }) },
          h(TableBox, { rows: act.top_downloaders.map(r => ({ ...r, id: r.user })), columns: dlCols, total: act.downloaders_total, empty: 'No downloads in the last 30 days.', coreHint: 'Opens the Access Log filtered to this project' }))),
      h(Panel, { title: 'Changes to data and access', sub: 'Last 30 days, newest first (Access Log)', wide: true, right: h(Tag, { color: events.length ? 'orange' : 'green', title: fmtNum(act.changes_total + act.access_changes.reduce((n, e) => n + e.n, 0)) }) },
        h(TableBox, { rows: events.map((r, i) => ({ ...r, id: `${r.type}-${r.user}-${i}` })), columns: evCols, empty: 'No deletes, replacements, moves, syncs or permission changes in the last 30 days.', coreHint: 'Opens the Access Log filtered to this project' })));
  }

  function Pipeline({ steps, compact }) {
    const top = Math.max(1, steps[0].n);
    return h('div', { className: 'psd-pipe' + (compact ? ' compact' : '') },
      steps.map((s, i) => {
        const prev = i ? steps[i - 1].n : null;
        const drop = prev != null ? prev - s.n : 0;
        return h('div', { key: s.key, className: 'psd-pipe-step' },
          h('div', { className: 'psd-pipe-head' },
            h('span', { className: 'psd-pipe-label' }, s.label),
            !compact && h('span', { className: 'psd-pipe-owner' }, LENS[s.owner].label)),
          h('div', { className: 'psd-pipe-bar' }, h('span', { style: { width: `${(s.n / top) * 100}%`, background: `var(--${LENS[s.owner].color}-base)` } })),
          h('div', { className: 'psd-pipe-nums' },
            h('b', null, fmtNum(s.n)),
            h('span', null, fmtPct(s.n / top)),
            drop > 0 && h('em', { title: `${drop} sessions stopped before this step` }, `−${fmtNum(drop)}`)));
      }));
  }

  // ------------------------------------------------------------ UI pieces
  const SRC = { live: { label: 'Live', title: 'Counted on page load (one count query, no paging)' }, snap: { label: 'Snapshot', title: 'From the latest snapshot gear run' } };
  function SrcMark({ src }) {
    return src ? h('span', { className: 'psd-src src-' + src, title: SRC[src].title }, h('i', null), SRC[src].label) : null;
  }
  function Kpi({ label, value, sub, tone, progress, progressColor, src }) {
    return h('div', { className: 'psd-kpi' + (tone ? ' tone-' + tone : '') },
      h('div', { className: 'psd-kpi-label' }, h('span', null, label), h(SrcMark, { src })),
      h('div', { className: 'psd-kpi-value' }, value),
      progress != null && h('div', { className: 'psd-kpi-bar' }, h(ProgressBar, { value: Math.round(progress * 100), color: progressColor || 'green' })),
      sub && h('div', { className: 'psd-kpi-sub' }, sub));
  }
  function Panel({ title, sub, children, wide, right }) {
    return h('div', { className: 'psd-panel' + (wide ? ' wide' : '') },
      h(PanelLayout, { border: 'all', height: 'auto', header: h('div', { className: 'psd-panel-head' },
        h('div', null, h(Typography, { variant: 'h4' }, title), sub && h(Typography, { variant: 'p4', color: 'light' }, sub)), right) }, children));
  }
  function TableBox({ rows, columns, empty, onRowClick, tall, total, coreHint }) {
    const more = total != null && total > rows.length;
    return h('div', { className: 'psd-tbl' },
      h('div', { className: 'psd-table-wrap' + (tall ? ' tall' : '') }, h(Table, { dense: true, sticky: true, rowKey: 'id', rows, columns, emptyText: empty || 'Nothing here.', onRowClick })),
      more && h('div', { className: 'psd-tbl-foot' },
        h('span', null, `Showing ${rows.length.toLocaleString()} of ${total.toLocaleString()}`),
        h(Button, { size: 'small', variant: 'ghost', color: 'primary', endIcon: 'open', disabled: true, title: `${coreHint || 'Opens the full list in Flywheel Core'} (disabled in the prototype)` }, 'View all in Core')));
  }
  function MiniBar({ value, color }) {
    return h('div', { className: 'psd-mini' }, h('span', { style: { width: `${Math.round((value || 0) * 100)}%`, background: `var(--${color || 'green'}-base)` } }), h('em', null, fmtPct(value)));
  }
  function LensDot({ lens, health, onClick }) {
    return h('button', { className: 'psd-lensdot', onClick, title: `${LENS[lens].label}: ${HEALTH[health].label}` },
      h('i', { className: 'h-' + health }), h('span', null, HEALTH[health].label));
  }
  // Live tier refreshes every 60 s (and on tab focus); the snapshot gear targets a 15-minute cadence.
  const LIVE_EVERY_S = 60, SNAP_TARGET_MIN = 15;
  function useTick() {
    const [t, setT] = useState(Date.now());
    useEffect(() => { const i = setInterval(() => setT(Date.now()), 1000); return () => clearInterval(i); }, []);
    return t;
  }
  function Fresh({ f }) {
    const t = useTick();
    const sinceLive = Math.floor(((t - f.live.fetched_at) / 1000) % LIVE_EVERY_S);
    const age = (t - f.generated_at) / 60000;
    return h('div', { className: 'psd-fresh' },
      h(SrcMark, { src: 'live' }), h('span', { title: `Counts refresh every ${LIVE_EVERY_S} s and when the tab regains focus (demo: values are static)` }, `updated ${sinceLive} s ago`),
      h(SrcMark, { src: 'snap' }), f.source === 'browser' ? h('span', { title: 'Computed in this browser from live records (sandbox-size project). The snapshot gear replaces this at scale.' }, `analysis ${fmtAgo(f.generated_at, t)} · in browser, every 60 s`)
        : h('span', { className: age > SNAP_TARGET_MIN * 2 ? 'stale' : null, title: `Snapshot gear target: every ${SNAP_TARGET_MIN} min` }, `analysis ${fmtAgo(f.generated_at, t)} · every ${SNAP_TARGET_MIN} min`));
  }
  function SinceSnapshot({ f, now }) {
    const L = f.live;
    const item = (n, label, tone) => h('div', { className: 'psd-delta-item' + (tone && n ? ' tone-' + tone : '') }, h('b', null, `${n ? '+' : ''}${fmtNum(n)}`), h('span', null, label));
    return h('div', { className: 'psd-delta' },
      h('div', { className: 'psd-delta-head' }, h('span', { className: 'psd-strong' }, L.label || 'Since the last analysis'), h('span', { className: 'psd-sub' }, `${fmtAgo(L.since, now)} → now`), h(SrcMark, { src: 'live' })),
      h('div', { className: 'psd-delta-row' },
        item(L.sessions_new, 'sessions uploaded'), item(L.jobs_new, 'jobs started'), item(L.failed_new, 'jobs failed', 'warn'), item(L.reads_completed_new, 'reads completed')),
      L.failures.length ? h('ul', { className: 'psd-delta-list' }, L.failures.map(x => h('li', { key: x.id },
        h('i', { className: 'h-act' }), h('code', null, `${x.gear} ${x.version}`), h('span', null, x.reason || '—'), h('span', { className: 'psd-sub' }, fmtAgo(x.at, now))))) : null);
  }

  function Attention({ items, onGo, persona, limit }) {
    const list = persona === 'all' ? items : items.filter(a => a.lens === persona);
    const shown = limit ? list.slice(0, limit) : list;
    if (!list.length) return h('div', { className: 'psd-empty' }, h(Icon, { name: 'done-check', color: 'green', size: 'small', decorative: true }), 'Nothing needs attention.');
    return h('ul', { className: 'psd-att' }, shown.map(a => h('li', { key: a.id, className: 'sev-' + a.sev },
      h('span', { className: 'psd-att-sev' }, h(HealthTag, { h: a.sev })),
      h('div', { className: 'psd-att-body' },
        h('div', { className: 'psd-att-title' }, a.title, a.project && h('span', { className: 'psd-att-proj' }, a.project)),
        h('div', { className: 'psd-att-detail' }, a.detail)),
      h(Tag, { color: LENS[a.lens].color, icon: LENS[a.lens].icon, title: LENS[a.lens].persona }),
      h(Button, { size: 'small', variant: 'ghost', color: 'primary', endIcon: 'chevron-forward', onClick: () => onGo(a) }, 'Open'))));
  }

  function LensCard({ lens, health, metrics, onOpen, active }) {
    return h('div', { className: 'psd-lens' + (active ? ' active' : '') },
      h('div', { className: 'psd-lens-head' },
        h('div', { className: 'psd-lens-title' }, h(Icon, { name: LENS[lens].icon, color: LENS[lens].color, size: 'small', decorative: true }),
          h('div', null, h(Typography, { variant: 'h4' }, LENS[lens].label), h(Typography, { variant: 'p4', color: 'light' }, LENS[lens].persona))),
        h(HealthTag, { h: health, size: 'large' })),
      h('dl', { className: 'psd-lens-metrics' }, metrics.map(([k, v, tone]) => h('div', { key: k }, h('dt', null, k), h('dd', { className: tone ? 'tone-' + tone : null }, v)))),
      health !== 'na' && h(Button, { size: 'small', variant: 'outlined', color: 'primary', endIcon: 'chevron-forward', onClick: onOpen }, `Open ${LENS[lens].label}`));
  }

  // ------------------------------------------------------------ Info and About
  function InfoPanel({ ctx, onClose, sel, now, diag }) {
    const gearsSeen = sel ? sel.f.compute.gears.filter(g => g.versions.length) : [];
    const libs = [
      ['React', '18.3.1', 'MIT', 'https://github.com/facebook/react/tree/v18.3.1'],
      ['React DOM', '18.3.1', 'MIT', 'https://github.com/facebook/react/tree/v18.3.1'],
      ['Flywheel Vision Design System (React subset)', 'vision-react, built Nov 2026', 'Flywheel internal', 'https://claude.ai/artifact/VWFDvStzgRxSSJzChTnXt9'],
      ['Flywheel-Vision-Icons font + glyph map', '@flywheel-io/vision 22.1.2', 'Flywheel', 'https://www.npmjs.com/package/@flywheel-io/vision'],
      ['Inter', 'Google Fonts', 'OFL-1.1', 'https://github.com/rsms/inter'],
      ['Flywheel Extension SDK', '0.14.9 — not loaded in the prototype', 'MIT', null],
    ];
    const sec = (title, ...c) => h('section', { className: 'psd-info-sec' }, h(Typography, { variant: 'h5' }, title), ...c);
    const kv = rows => h('dl', { className: 'psd-kv' }, rows.map(([k, v]) => [h('dt', { key: k + 't' }, k), h('dd', { key: k + 'd' }, v)]));
    const a = (href, text) => (href ? h('a', { href, target: '_blank', rel: 'noopener noreferrer' }, text) : text);
    return h('aside', { className: 'psd-info', 'aria-label': 'Info and About' },
      h('div', { className: 'psd-info-head' }, h(Typography, { variant: 'h4' }, 'Info'), h(IconButton, { icon: 'close', size: 'small', color: 'slate', 'aria-label': 'Close info', onClick: onClose })),
      h('div', { className: 'psd-info-body' },
        sec('Context', kv([[ctx.live ? 'Site' : 'Group', ctx.group], ['Viewing', ctx.viewing], ['View as', ctx.persona], ['User', ctx.live ? String(ctx.user) : 'demo-user (no sign-in)']])),
        diag && sec('Diagnostics (harness)', diag),
        sec('Application', kv([['App', `${BUILD.app} ${BUILD.version}`], ['Build', `${BUILD.mode}${BUILD.built ? ' · ' + BUILD.built : ''}`], ['Data', ctx.live ? 'Live, read-only (Extension SDK, GET only)' : 'Demo (synthetic)'], ['Tier', 'Research use only — not validated'], ['Writes', 'None. Read-only by design.']])),
        sel && sec('Snapshot (this project)', kv([
          ['Schema', h('code', null, sel.f.schema)], ['Generated', `${new Date(sel.f.generated_at).toLocaleString()} (${fmtAgo(sel.f.generated_at, now)})`],
          ['Size', `${(JSON.stringify(sel.f).length / 1024).toFixed(0)} KB for ${fmtNum(sel.f.statistics.sessions)} sessions and ${fmtNum(sel.f.statistics.jobs)} jobs`],
          ['Produced by', sel.f.source === 'browser' ? 'buildFacts() over live records in this browser (sandbox-size project; the snapshot gear replaces this at scale)' : sel.f.project.info.scale_demo ? 'Synthetic facts at real-project scale (no raw records)' : 'buildFacts() in the browser, standing in for the snapshot gear']])),
        sec('Algorithms (this view)',
          h(Typography, { variant: 'p4', color: 'muted' }, 'This app displays no gear output. It reports pipeline health from job records. Gears seen in the last 7 days:'),
          gearsSeen.length ? h('ul', { className: 'psd-info-list' }, gearsSeen.map(g => h('li', { key: g.gear }, h('code', null, `${g.gear} ${g.versions.map(v => v.version).join(', ')}`)))) : h(Typography, { variant: 'p4', color: 'light' }, 'Open a project to list its gears.')),
        sec('Method', h('ul', { className: 'psd-info-list' },
          h('li', null, 'Freshness budget: Live counts ≤ 60 s (poll + on focus); "Since the last analysis" = live count-only queries with created > snapshot time; Snapshot ≤ 15 min (incremental gear by watermark). Target with platform events: seconds.'),
          h('li', null, 'Two tiers. Live: the six project totals (GET /api/projects/{id} → statistics) and count-only queries (limit=1, read total). Snapshot: a scheduled gear streams sessions, jobs and tasks once and writes a facts document; the browser never loads raw records.'),
          h('li', null, 'Template complete = sessions satisfying their session template ÷ all sessions. Action < 85%, Watch < 95% or a site silent for 21 days.'),
          h('li', null, 'Reads: primary reader tasks, cancelled excluded. Overdue = open and past the due date (calendar day). Stalled = in progress, no change for 7 days. Action when ≥ 10% of open reads are overdue (and ≥ 5); Watch at ≥ 2% overdue or stalled, or any when fewer than 50 reads are open.'),
          h('li', null, 'Compute, last 7 days: failure rate = failed ÷ (complete + failed). Action ≥ 15%, Watch ≥ 5%. Gears are judged after 10 finished runs. Queue: Watch when the p95 wait of jobs pending now exceeds 60 min. A disabled gear rule is Watch.'),
          h('li', null, 'Activity (Data tab): from the site Access Log. Rows are aggregated (a count with first and last access), so events are dated by last access (approximate). Active users = distinct people with any non-login action in the window. Downloads: Watch when the last 7 days exceed 3× the usual week (median of the 4 before) and ≥ 100. Data changes = deletes, replacements, moves and external syncs. No subject labels are kept.'),
          h('li', null, 'Pipeline complete = the latest job of every enabled rule gear on the session is complete. Project health = the worst lens. All thresholds are app options (verify defaults with the study teams).'))),
        sec('Data sources', h('ul', { className: 'psd-info-list mono' },
          h('li', null, 'LIVE /api/projects/{id} → statistics (verified r6nvg8)'),
          h('li', null, 'LIVE /api/jobs?filter=state=…,parents.project=…&limit=1 → total (state filter verified; project syntax and time window: verify)'),
          h('li', null, 'LIVE /api/tasks/reader?filter=parents.project=…&limit=1 → total'),
          h('li', null, 'LIVE /api/report/accesslog?reportType=accesslog&limit=10000 (read once per page load; site admins verified on r6nvg8, others: verify)'),
          h('li', null, 'SNAPSHOT project file project-status.summary.json (planned gear)'))),
        sec('Libraries', h('table', { className: 'psd-info-table' }, h('tbody', null, libs.map(([n, v, lic, url]) => h('tr', { key: n }, h('td', null, a(url, n)), h('td', null, v), h('td', null, lic)))))),
        sec('Data', h(Typography, { variant: 'p4', color: 'muted' }, ctx.live ? 'Live project, session, job, gear-rule and reader-task records from this Flywheel site, read with your permissions. Nothing is written.' : 'Synthetic. Group "GNE", seven fictional projects. ONC-9100 is sized like a real GNE production project (~160k sessions, ~5.9M jobs) but every name and number is invented.'))));
  }

  // ------------------------------------------------------------ portfolio
  function Portfolio({ sums, persona, now, onOpen }) {
    const rows = sums.map(({ f, a }) => ({
      id: f.project._id, f, a,
      name: f.project.label, tier: f.project.info.tier, health: a.health,
      dh: a.data.health, th: a.tasks.health, ch: a.compute.health,
      sessions: f.statistics.sessions, jobs: f.statistics.jobs, last: f.data.last,
      att: a.attention.filter(x => x.sev === 'act' || x.sev === 'watch').length,
      sev: PSDL.SEV[persona === 'all' ? a.health : a[persona].health],
    })).sort((x, y) => y.sev - x.sev || PSDL.natural(x.name, y.name));
    const all = sums.flatMap(({ f, a }) => a.attention.map(x => ({ ...x, id: f.project._id + x.id, project: f.project.info.study_code, pid: f.project._id })));
    const tot = fn => sums.reduce((acc, s) => acc + (fn(s) || 0), 0);
    const count = k => ({ act: 0, watch: 0, ok: 0, ...rows.reduce((m, r) => ((m[r[k]] = (m[r[k]] || 0) + 1), m), {}) });
    const lensCount = ['dh', 'th', 'ch'].map(count);
    const cell = (lens, key) => r => (r.f.stub ? h('span', { className: 'psd-sub', title: r.f.stub }, 'Totals only') : h(LensDot, { lens, health: r[key], onClick: e => { e.stopPropagation(); onOpen(r.id, lens); } }));
    const columns = [
      { key: 'name', header: 'Project', sortable: true, render: r => h('div', { className: 'psd-proj' }, h('span', { className: 'psd-strong' }, r.name),
        h('span', { className: 'psd-sub' }, `${r.tier} · ${fmtNum(r.sessions)} sessions · ${fmtNum(r.jobs)} jobs · last upload ${fmtAgo(r.last, now)}${r.f.activity && r.f.activity.available ? ` · last activity ${r.f.activity.last ? fmtAgo(r.f.activity.last, now) : 'none'}` : ''}`)) },
      { key: 'sev', header: 'Overall', sortable: true, width: 110, render: r => h(HealthTag, { h: r.health }) },
      { key: 'dh', header: 'Data', width: 110, render: cell('data', 'dh') },
      { key: 'th', header: 'Tasks', width: 110, render: cell('tasks', 'th') },
      { key: 'ch', header: 'Compute', width: 110, render: cell('compute', 'ch') },
      { key: 'pipe', header: 'Session pipeline', width: 240, render: r => (r.a.steps.length ? h(Pipeline, { steps: r.a.steps, compact: true }) : h('span', { className: 'psd-sub' }, r.f.stub ? 'Needs snapshot gear' : '—')) },
      { key: 'snap', header: 'Analysis', width: 100, render: r => h('span', { className: 'psd-sub' }, r.f.stub ? '—' : r.f.source === 'browser' ? 'in browser' : fmtAgo(r.f.generated_at, now)) },
      { key: 'att', header: 'Open items', sortable: true, align: 'right', width: 96, render: r => (r.att ? h(Tag, { color: 'orange', title: String(r.att) }) : '0') },
    ];
    return h('div', { className: 'psd-body' },
      h('div', { className: 'psd-kpis' },
        h(Kpi, { label: 'Projects', value: sums.length, sub: `${lensCount.reduce((acc, c) => acc + c.act, 0)} lens calls at Action` }),
        h(Kpi, { label: 'Sessions', value: fmtNum(tot(s => s.f.statistics.sessions)), sub: `${fmtNum(tot(s => s.f.data.recent))} in the last 7 d`, src: 'live' }),
        h(Kpi, { label: 'Jobs', value: fmtNum(tot(s => s.f.statistics.jobs)), sub: `${fmtNum(tot(s => s.f.compute.failed))} failed in the last 7 d`, src: 'live' }),
        h(Kpi, { label: 'Missing required data', value: fmtNum(tot(s => s.f.data.missing_total)), sub: 'sessions failing their template', tone: tot(s => s.f.data.missing_total) ? 'warn' : null, src: 'snap' }),
        h(Kpi, { label: 'Open reads', value: fmtNum(tot(s => s.f.tasks.used && s.f.tasks.open)), sub: `${fmtNum(tot(s => s.f.tasks.used && s.f.tasks.overdue_total))} overdue`, src: 'live' }),
        h(Kpi, { label: 'Jobs queued', value: fmtNum(tot(s => s.f.compute.pending_total)), sub: `${fmtNum(tot(s => s.f.compute.running))} running now`, src: 'live' })),
      h('div', { className: 'psd-lens-strip' }, ['data', 'tasks', 'compute'].map((k, i) => h('div', { key: k, className: 'psd-strip-item' + (persona === k ? ' active' : '') },
        h(Icon, { name: LENS[k].icon, color: LENS[k].color, size: 'small', decorative: true }),
        h('span', { className: 'psd-strong' }, LENS[k].persona),
        ['act', 'watch', 'ok'].map(sv => h('span', { key: sv, className: 'psd-count' }, h('i', { className: 'h-' + sv }), `${lensCount[i][sv]} ${HEALTH[sv].label}`))))),
      h('div', { className: 'psd-stack flush' },
        h(Panel, { title: 'Projects', sub: persona === 'all' ? 'Sorted by overall health' : `Sorted by ${LENS[persona].label} health`, wide: true },
          h(TableBox, { rows, columns, onRowClick: r => onOpen(r.id, persona === 'all' ? 'overview' : persona), tall: true })),
        h(Panel, { title: 'Needs attention', sub: persona === 'all' ? 'All projects, most severe first' : `${LENS[persona].persona} items, all projects`, wide: true },
          h(Attention, { items: all.filter(x => x.sev === 'act' || x.sev === 'watch'), persona, limit: 14, onGo: x => onOpen(x.pid, x.go) }))));
  }

  // ------------------------------------------------------------ project
  function ProjectView({ s, tab, persona, now }) {
    const { f, a } = s;
    const d = f.data, t = f.tasks, c = f.compute, st = f.statistics;
    const setTab = v => go(`#p-${f.project._id}-${v}`);
    const overview = h('div', { className: 'psd-stack' },
      h(SinceSnapshot, { f, now }),
      h('div', { className: 'psd-statline' }, [['Subjects', st.subjects], ['Sessions', st.sessions], ['Acquisitions', st.acquisitions], ['Acquisition files', st.acquisition_files], ['Analyses', st.analyses], ['Jobs', st.jobs]]
        .map(([k, v]) => h('div', { key: k }, h('b', null, fmtNum(v)), h('span', null, k))), h(SrcMark, { src: 'live' })),
      h('div', { className: 'psd-lenses' },
        h(LensCard, { lens: 'data', health: a.data.health, active: persona === 'data', onOpen: () => setTab('data'), metrics: [
          ['Template complete', fmtPct(a.data.share), a.data.health === 'act' ? 'act' : null], ['Missing required data', fmtNum(d.missing_total)], ['Uploaded, 7 d', fmtNum(d.recent)], ['Last upload', fmtAgo(d.last, now)]] }),
        h(LensCard, { lens: 'tasks', health: a.tasks.health, active: persona === 'tasks', onOpen: () => setTab('tasks'), metrics: t.used ? [
          ['Reads complete', fmtPct(a.tasks.share)], ['Open reads', fmtNum(t.open)], ['Overdue', fmtNum(t.overdue_total), t.overdue_total ? (a.tasks.health === 'act' ? 'act' : 'watch') : null], ['Stalled', fmtNum(t.stalled_total), t.stalled_total ? 'watch' : null]]
          : [['Reader tasks', 'None — no reads in this project']] }),
        h(LensCard, { lens: 'compute', health: a.compute.health, active: persona === 'compute', onOpen: () => setTab('compute'), metrics: [
          ['Failure rate, 7 d', fmtPct(a.compute.rate), a.compute.health === 'act' ? 'act' : null], ['Jobs, 7 d', fmtNum(c.jobs_window)], ['Running / queued', `${fmtNum(c.running)} / ${fmtNum(c.pending_total)}`], ['Queue p95 wait', fmtMin(c.queue_p95_min), a.compute.queueSlow ? 'watch' : null]] })),
      h('div', { className: 'psd-grid two' },
        h(Panel, { title: 'Session pipeline', sub: 'Where each session sits, from upload to final read', right: h(SrcMark, { src: 'snap' }) }, h(Pipeline, { steps: a.steps }),
          f.pipeline.flow && f.pipeline.flow.length ? h('div', { className: 'psd-pipe-more' }, h(Button, { size: 'small', variant: 'ghost', endIcon: 'chevron-forward', onClick: () => setTab('compute') }, 'Rule flow')) : null),
        h(Panel, { title: 'Needs attention', sub: persona === 'all' ? 'Every lens, most severe first' : `${LENS[persona].persona} items` },
          h(Attention, { items: a.attention, persona, onGo: x => setTab(x.go) }))));

    const siteRows = [...a.data.sites].sort((x, y) => PSDL.SEV[y.health] - PSDL.SEV[x.health] || (x.share || 0) - (y.share || 0)).slice(0, PSDL.TOP_N);
    const siteCols = [
      { key: 'site', header: 'Site', sortable: true, render: r => h('span', { className: 'psd-strong' }, r.site) },
      { key: 'subjects', header: 'Subjects', sortable: true, align: 'right', render: r => fmtNum(r.subjects) },
      { key: 'sessions', header: 'Sessions', sortable: true, align: 'right', render: r => fmtNum(r.sessions) },
      { key: 'share', header: 'Template complete', sortable: true, width: 170, render: r => h(MiniBar, { value: r.share, color: r.health === 'act' ? 'red' : r.share < 0.95 ? 'orange' : 'green' }) },
      { key: 'last', header: 'Last upload', sortable: true, render: r => fmtAgo(r.last, now) },
      { key: 'health', header: 'Status', render: r => h(HealthTag, { h: r.health }) },
    ];
    const missCols = [
      { key: 'subject', header: 'Subject', sortable: true, render: r => h('span', { className: 'psd-strong' }, r.subject) },
      { key: 'visit', header: 'Visit', sortable: true }, { key: 'site', header: 'Site', sortable: true },
      { key: 'missing', header: 'Missing' }, { key: 'created', header: 'Uploaded', sortable: true, render: r => fmtDay(r.created) },
      { key: 'go', header: '', align: 'right', render: () => h(Button, { size: 'small', variant: 'ghost', endIcon: 'open', title: 'Opens the session in Flywheel Core (disabled in the prototype)', disabled: true }, 'Session') },
    ];
    const dataTab = a.unavailable && a.unavailable.data ? h('div', { className: 'psd-stack' }, a.unavailable.data) : h('div', { className: 'psd-stack' },
      h('div', { className: 'psd-kpis' },
        h(Kpi, { label: 'Subjects', value: fmtNum(st.subjects), src: 'live' }), h(Kpi, { label: 'Sessions', value: fmtNum(st.sessions), src: 'live' }),
        h(Kpi, { label: 'Template complete', value: fmtPct(a.data.share), progress: a.data.share, progressColor: a.data.health === 'act' ? 'red' : a.data.share < 0.95 ? 'orange' : 'green', tone: a.data.health === 'act' ? 'attention' : null, src: 'snap' }),
        h(Kpi, { label: 'Missing required data', value: fmtNum(d.missing_total), tone: d.missing_total ? 'warn' : null, src: 'snap' }),
        h(Kpi, { label: 'Uploaded, 7 d', value: fmtNum(d.recent), src: 'live' }), h(Kpi, { label: 'Last upload', value: fmtAgo(d.last, now), src: 'live' })),
      h('div', { className: 'psd-grid two' },
        h(Panel, { title: 'Sessions uploaded per week', sub: `Last ${d.weekly.length} weeks, by upload date`, right: h(SrcMark, { src: 'snap' }) }, h(WeeklyBars, { points: d.weekly, label: 'Sessions uploaded per week', color: 'var(--primary-base)' })),
        h(Panel, { title: 'Sites', sub: d.sites_total > siteRows.length ? 'Sites needing attention first' : null, right: h(SrcMark, { src: 'snap' }) },
          h(TableBox, { rows: siteRows, columns: siteCols, total: d.sites_total, coreHint: 'Opens the session list grouped by site' }))),
      h(Panel, { title: 'Sessions missing required data', sub: 'Session template not satisfied, newest first', wide: true, right: h(Tag, { color: d.missing_total ? 'orange' : 'green', title: fmtNum(d.missing_total) }) },
        h(TableBox, { rows: d.missing, columns: missCols, total: d.missing_total, empty: 'Every session satisfies its template.', coreHint: 'Opens sessions filtered to template not satisfied' })),
      f.activity && h('div', { className: 'psd-section-head' }, h(Typography, { variant: 'h4' }, 'Activity')),
      h(ActivitySection, { act: f.activity, now }));

    const readerCols = [
      { key: 'reader', header: 'Reader', sortable: true, render: r => h('span', { className: 'psd-strong' }, r.reader) },
      { key: 'total', header: 'Assigned', sortable: true, align: 'right', render: r => fmtNum(r.total) }, { key: 'completed', header: 'Completed', sortable: true, align: 'right', render: r => fmtNum(r.completed) },
      { key: 'rate', header: 'Completion', sortable: true, width: 150, render: r => h(MiniBar, { value: r.total ? r.completed / r.total : null }) },
      { key: 'turnaround_days', header: 'Median turnaround', sortable: true, align: 'right', render: r => (r.turnaround_days == null ? '—' : `${r.turnaround_days.toFixed(1)} d`) },
      { key: 'open', header: 'Open', sortable: true, align: 'right' },
      { key: 'overdue', header: 'Overdue', sortable: true, align: 'right', render: r => (r.overdue ? h(Tag, { color: 'red', title: String(r.overdue) }) : '0') },
      { key: 'stalled', header: 'Stalled', sortable: true, align: 'right', render: r => (r.stalled ? h(Tag, { color: 'orange', title: String(r.stalled) }) : '0') },
    ];
    const overCols = [
      { key: 'task_id', header: 'Task', render: r => h('code', null, r.task_id) }, { key: 'reader', header: 'Reader' },
      { key: 'status', header: 'Status', render: r => h(Tag, { color: r.status === 'in_progress' ? 'primary' : 'slate', title: r.status === 'in_progress' ? 'In progress' : 'To do' }) },
      { key: 'due', header: 'Due', render: r => fmtDay(r.due) },
      { key: 'overdueDays', header: 'Days overdue', align: 'right', render: r => h(Tag, { color: r.overdueDays > 7 ? 'red' : 'orange', title: String(r.overdueDays) }) },
      { key: 'go', header: '', align: 'right', render: () => h(Button, { size: 'small', variant: 'ghost', endIcon: 'open', title: 'Opens the task in Task Admin Console (disabled in the prototype)', disabled: true }, 'Task') },
    ];
    const tasksTab = !t.used ? h(ContextLayout, { icon: 'reader-studies', title: 'No reader tasks', description: 'This project has no read protocol. Tasks status appears once reader tasks exist.' })
      : h('div', { className: 'psd-stack' },
        h('div', { className: 'psd-kpis' },
          h(Kpi, { label: 'Primary reads', value: fmtNum(t.total), src: 'live' }),
          h(Kpi, { label: 'Complete', value: fmtPct(a.tasks.share), progress: a.tasks.share, sub: `${fmtNum(t.completed)} of ${fmtNum(t.total)}`, src: 'live' }),
          h(Kpi, { label: 'Open', value: fmtNum(t.open), sub: t.unassigned ? `${fmtNum(t.unassigned)} unassigned` : null, src: 'live' }),
          h(Kpi, { label: 'Overdue', value: fmtNum(t.overdue_total), sub: t.open ? `${fmtPct(t.overdue_total / t.open)} of open` : null, tone: a.tasks.health === 'act' ? 'attention' : t.overdue_total ? 'warn' : null, src: 'live' }),
          h(Kpi, { label: 'Stalled', value: fmtNum(t.stalled_total), sub: 'no activity > 7 d', tone: t.stalled_total ? 'warn' : null, src: 'snap' }),
          h(Kpi, { label: 'Adjudication', value: fmtNum(t.adj_open), sub: `${fmtNum(t.adj_blocked)} waiting on comparison`, src: 'live' })),
        h('div', { className: 'psd-grid two' },
          h(Panel, { title: 'Reads completed per week', sub: `Last ${t.weekly.length} full weeks`, right: h(SrcMark, { src: 'snap' }) }, h(WeeklyBars, { points: t.weekly, label: 'Reads completed per week', color: 'var(--secondary-base)' })),
          h(Panel, { title: 'Open reads by age', sub: 'Days since the task was created', right: h(SrcMark, { src: 'snap' }) }, h(AgeBars, { data: t.age }))),
        h(Panel, { title: 'Readers', wide: true, right: h(SrcMark, { src: 'snap' }) }, h(TableBox, { rows: t.readers.map(r => ({ ...r, id: r.reader })), columns: readerCols, total: t.readers_total })),
        h(Panel, { title: 'Overdue reads', sub: 'Most overdue first', wide: true, right: h(Tag, { color: t.overdue_total ? 'red' : 'green', title: fmtNum(t.overdue_total) }) },
          h(TableBox, { rows: t.overdue, columns: overCols, total: t.overdue_total, empty: 'No overdue reads.', coreHint: 'Opens Task Admin Console filtered to overdue' })));

    const gearCols = [
      { key: 'gear', header: 'Gear', sortable: true, render: r => h('div', { className: 'psd-proj' }, h('span', { className: 'psd-strong' }, r.gear), h('code', { className: 'psd-sub' }, r.version_text)) },
      { key: 'rule', header: 'Rule', render: r => h(Tag, { color: r.rule === 'disabled' ? 'orange' : r.rule === 'on' ? 'green' : 'slate', title: r.rule === 'disabled' ? 'Disabled' : r.rule === 'on' ? 'On' : 'Manual' }) },
      { key: 'runs', header: 'Runs, 7 d', sortable: true, align: 'right', render: r => fmtNum(r.runs) }, { key: 'failed', header: 'Failed', sortable: true, align: 'right', render: r => fmtNum(r.failed) },
      { key: 'rate', header: 'Failure rate', sortable: true, width: 150, render: r => (r.rate == null ? '—' : h(MiniBar, { value: r.rate, color: r.health === 'act' ? 'red' : r.health === 'watch' ? 'orange' : 'slate' })) },
      { key: 'median_min', header: 'Median run', sortable: true, align: 'right', render: r => fmtMin(r.median_min) },
      { key: 'top_reason', header: 'Top failure cause' },
    ];
    const failCols = [
      { key: 'gear', header: 'Gear', render: r => h('code', null, `${r.gear} ${r.version}`) },
      { key: 'reason', header: 'Cause', render: r => r.reason || '—' },
      { key: 'launched_by', header: 'Launched by' },
      { key: 'at', header: 'Failed', render: r => fmtAgo(r.at, now) },
      { key: 'go', header: '', align: 'right', render: () => h(Button, { size: 'small', variant: 'ghost', endIcon: 'open', title: 'Opens the job log in Flywheel Core (disabled in the prototype)', disabled: true }, 'Job log') },
    ];
    const pendCols = [
      { key: 'gear', header: 'Gear', render: r => h('code', null, `${r.gear} ${r.version}`) },
      { key: 'launched_by', header: 'Launched by' },
      { key: 'wait_min', header: 'Waiting', align: 'right', render: r => h(Tag, { color: r.wait_min > 60 ? 'orange' : 'slate', title: fmtMin(r.wait_min) }) },
    ];
    const unavail = (k) => a.unavailable && a.unavailable[k] ? h(AlertPanel, { severity: 'warning', icon: 'lock', title: 'Not available with this access', description: `${a.unavailable[k]}. The lens is shown as Unavailable rather than empty; see Info › Diagnostics.` }) : null;
    const computeTab = a.unavailable && a.unavailable.compute ? h('div', { className: 'psd-stack' }, unavail('compute')) : h('div', { className: 'psd-stack' },
      h('div', { className: 'psd-kpis' },
        h(Kpi, { label: 'Jobs, 7 d', value: fmtNum(c.jobs_window), src: 'live' }),
        h(Kpi, { label: 'Failure rate, 7 d', value: fmtPct(a.compute.rate), sub: `${fmtNum(c.failed)} of ${fmtNum(c.finished)} finished`, tone: a.compute.health === 'act' ? 'attention' : a.compute.rate >= 0.05 ? 'warn' : null, src: 'live' }),
        h(Kpi, { label: 'Running', value: fmtNum(c.running), src: 'live' }),
        h(Kpi, { label: 'Queued', value: fmtNum(c.pending_total), sub: c.pending_total ? `p95 wait ${fmtMin(c.queue_p95_min)}` : null, tone: a.compute.queueSlow ? 'warn' : null, src: 'live' }),
        h(Kpi, { label: 'Median queue wait, 7 d', value: fmtMin(c.median_wait_min), src: 'snap' }),
        h(Kpi, { label: 'Compute time, 7 d', value: c.hours ? `${fmtNum(Math.round(c.hours))} h` : '—', sub: 'job run time (verify source)', src: 'snap' })),
      h(Panel, { title: 'Rule flow', sub: 'Gear rules in the order their latest runs usually happen on a session (approximate); bar = latest job of that gear on each session', wide: true, right: h(SrcMark, { src: 'snap' }) }, h(RuleFlow, { flow: f.pipeline.flow })),
      h('div', { className: 'psd-grid two' },
        h(Panel, { title: 'Finished jobs per day', sub: 'Last 14 days', right: h(SrcMark, { src: 'snap' }) }, h(DailyJobs, { days: c.daily })),
        h(Panel, { title: 'Queue', sub: 'Pending jobs, longest wait first', right: h(Tag, { color: a.compute.queueSlow ? 'orange' : 'slate', title: fmtNum(c.pending_total) }) },
          h(TableBox, { rows: c.pending, columns: pendCols, total: c.pending_total, empty: 'Queue is empty.', coreHint: 'Opens Jobs Log filtered to pending' }))),
      h(Panel, { title: 'Gears', sub: 'Runs in the last 7 days; rule state from the project’s gear rules', wide: true, right: h(SrcMark, { src: 'snap' }) }, h(TableBox, { rows: a.compute.gears, columns: gearCols })),
      h(Panel, { title: 'Failed, not yet re-run', sub: 'The latest run of that gear on the session failed', wide: true, right: h(Tag, { color: c.unresolved_total ? 'orange' : 'green', title: fmtNum(c.unresolved_total) }) },
        h(TableBox, { rows: c.unresolved, columns: failCols, total: c.unresolved_total, empty: 'Every failed job has a later successful run.', coreHint: 'Opens Jobs Log filtered to failed' })));

    const tabs = [['overview', 'Overview', 'speed-dashboard'], ['data', 'Data', LENS.data.icon], ['tasks', 'Tasks', LENS.tasks.icon], ['compute', 'Compute', LENS.compute.icon]];
    return h('div', { className: 'psd-body' },
      h('div', { className: 'psd-phead' },
        h('div', null,
          h('div', { className: 'psd-crumb' }, h('a', { href: '#projects' }, 'All projects'), h(Icon, { name: 'chevron-forward', size: 'small', color: 'light', decorative: true }), h('span', null, f.project.info.study_code)),
          h(Typography, { variant: 'h2' }, f.project.label),
          h('div', { className: 'psd-pfacts' },
            h(Tag, { color: f.project.info.tier === 'Validated' ? 'green' : 'secondary', title: f.project.info.tier }),
            h('span', null, f.project.info.indication), h('span', null, f.project.info.criteria),
            h('span', null, `${fmtNum(st.subjects)} subjects`), h('span', null, `${fmtNum(d.sites_total)} sites`))),
        h('div', { className: 'psd-phealth' },
          h(Fresh, { f }),
          h('div', { className: 'psd-phealth-tag' }, h(Typography, { variant: 'p4', color: 'light' }, 'Overall'), h(HealthTag, { h: a.health, size: 'large' })))),
      h(Tabs, { value: tab, onChange: setTab },
        tabs.map(([v, title, icon]) => h(Tab, { key: v, value: v, title, icon })),
        h(TabPanel, { value: 'overview', padded: false }, overview),
        h(TabPanel, { value: 'data', padded: false }, dataTab),
        h(TabPanel, { value: 'tasks', padded: false }, tasksTab),
        h(TabPanel, { value: 'compute', padded: false }, computeTab)));
  }

  // ------------------------------------------------------------ app
  // ------------------------------------------------------------ live helpers
  function stubFacts(p, reason, now) {
    const st = p.statistics || {};
    return { schema: 'project-status/facts@1', stub: reason, generated_at: now, window_days: 7,
      project: { _id: p._id, label: p.label, info: { study_code: p.label, indication: '—', tier: '—', criteria: '—', group: p.group } },
      statistics: { subjects: st.subjects || 0, sessions: st.sessions || 0, acquisitions: st.acquisitions || 0, acquisition_files: st.acquisition_files || 0, analyses: st.analyses || 0, jobs: st.jobs || 0 },
      data: { sessions: st.sessions || 0, recent: 0, last: null, missing_total: 0, sites_total: 0 }, tasks: { used: false }, compute: { failed: 0, pending_total: 0, running: 0 },
      live: { since: now, fetched_at: now, sessions_new: 0, jobs_new: 0, failed_new: 0, reads_completed_new: 0, failures: [] } };
  }
  function Diagnostics({ log, notes, sample }) {
    const last = log.slice(-60).reverse();
    const ok = log.filter(e => e.ok).length;
    return h('div', { className: 'psd-diag' },
      h(Typography, { variant: 'p4', color: 'muted' }, `${log.length} calls · ${ok} OK · ${log.length - ok} failed. GET only, ReadOnly scope.`),
      notes.length ? h('ul', { className: 'psd-info-list' }, notes.map((n, i) => h('li', { key: i }, n))) : null,
      h('table', { className: 'psd-info-table mono' }, h('tbody', null, last.map((e, i) => h('tr', { key: i },
        h('td', null, e.ok ? 'OK' : 'ERR'), h('td', null, e.path.replace(/[0-9a-f]{24}/g, '…')), h('td', null, `${e.ms} ms`),
        h('td', null, e.ok ? `${e.rows != null ? e.rows : '—'}${e.total != null ? ' / ' + e.total : ''}` : (e.status ? e.status + ' ' : '') + (e.error || '').slice(0, 60)))))),
      h(Typography, { variant: 'p5', color: 'light' }, 'Fields seen (first record per endpoint): ' +
        Object.entries(sample || {}).map(([k, v]) => `${k} → ${v && typeof v === 'object' ? Object.keys(v).slice(0, 24).join(', ') : typeof v}`).join(' | ')));
  }

  function App({ boot }) {
    const [theme, setTheme] = useState(store.get('psd-theme') || 'dark');
    const [persona, setPersona] = useState(store.get('psd-persona') || 'all');
    const [info, setInfo] = useState(false);
    const [facts, setFacts] = useState(boot.facts || null);
    const [progress, setProgress] = useState(null);
    const [failure, setFailure] = useState(null);
    const [log, setLog] = useState([]);
    const [notes, setNotes] = useState([]);
    const [sample, setSample] = useState({});
    const [now, setNow] = useState(boot.now);
    const live = boot.mode === 'live';
    const route = useRoute();
    const apiRef = useRef(null);
    useEffect(() => {
      document.documentElement.setAttribute('data-mode', theme);
      document.documentElement.classList.toggle('vision-dark', theme === 'dark');
      store.set('psd-theme', theme);
    }, [theme]);
    useEffect(() => { store.set('psd-persona', persona); }, [persona]);

    // live: load every visible project once, then keep the open project fresh
    useEffect(() => {
      if (!live) return;
      const entries = [];
      const logger = e => { entries.push(e); setLog([...entries]); };
      logger.sample = {};
      const ctx = { now: Date.now(), openedAt: boot.openedAt, options: { ...PSDL.DEFAULTS, ...(boot.options || {}) } };
      PSD_LIVE.loadSite(boot.ext, ctx, logger, (n, of) => setProgress({ n, of }))
        .then(({ results, siteNotes, api }) => {
          apiRef.current = { api, ctx, results };
          const fs = results.map(r => r.facts || stubFacts(r.project, r.tooBig || `Could not load: ${r.error}`, ctx.now));
          setNotes([...siteNotes, ...results.flatMap(r => (r.notes || []).map(n => `${r.project.label}: ${n}`)), ...results.filter(r => r.error).map(r => `${r.project.label}: ${r.error}`)]);
          setFacts(fs); setNow(Date.now());
          setSample({ ...logger.sample });
          if (!location.hash && boot.projectId && fs.some(f => f.project._id === boot.projectId)) go(`#p-${boot.projectId}-overview`);
        })
        .catch(e => setFailure(e.message || String(e)));
    }, []);
    useEffect(() => {
      if (!live || !facts) return;
      let busy = false, last = 0;
      const refresh = async () => {
        const r = parseHash(); const ref = apiRef.current;
        if (busy || !ref || r.view !== 'project' || Date.now() - last < 4000) return;
        busy = true; last = Date.now();
        try {
          const p = ref.results.find(x => x.project._id === r.pid);
          if (!p) return;
          const stats = await PSD_LIVE.refreshStats(ref.api, r.pid).catch(() => null);
          const proj = { ...p.project, statistics: stats || p.project.statistics };
          const res = p.facts ? await PSD_LIVE.loadProject(ref.api, proj, { ...ref.ctx, now: Date.now() }) : { tooBig: p.tooBig };
          const nf = res.facts || stubFacts(proj, res.tooBig || p.tooBig, Date.now());
          // A transient failure on refresh must not blank totals that loaded before.
          setFacts(prev => prev.map(f => { if (f.project._id !== r.pid) return f; const o = f.statistics || {}, n = nf.statistics || {};
            for (const k of ['acquisitions', 'acquisition_files', 'analyses']) if (n[k] == null && o[k] != null) n[k] = o[k]; nf.statistics = n; return f; }));
          setFacts(prev => prev.map(f => (f.project._id === r.pid ? nf : f))); setNow(Date.now());
        } finally { busy = false; }
      };
      const iv = setInterval(refresh, 60000);
      const onVis = () => { if (document.visibilityState === 'visible') refresh(); };
      document.addEventListener('visibilitychange', onVis); window.addEventListener('focus', onVis);
      return () => { clearInterval(iv); document.removeEventListener('visibilitychange', onVis); window.removeEventListener('focus', onVis); };
    }, [live, !!facts]);

    const sums = useMemo(() => (facts || []).map(f => ({ f, a: PSDL.assess(f, boot.options, now) })), [facts, now]);
    const current = route.view === 'project' ? sums.find(s => s.f.project._id === route.pid) : null;
    const tab = route.tab || 'overview';
    const open = (pid, lens) => go(`#p-${pid}-${lens && lens !== 'all' ? lens : 'overview'}`);
    const siteLabel = live ? boot.site : `Group ${boot.group.label}`;

    const header = h('header', { className: 'psd-top' },
      h('div', { className: 'psd-title' },
        h('img', { className: 'psd-mark', src: boot.markSrc, alt: '', width: 24, height: 24 }),
        h('div', null, h(Typography, { variant: 'h3' }, 'Project Status'), h(Typography, { variant: 'p4', color: 'light' }, `${siteLabel} · ${facts ? sums.length : '…'} projects`)),
        live ? h(Tag, { color: 'green', icon: 'server-checkmark', title: 'Live · read-only', size: 'large' }) : h(Tag, { color: 'orange', icon: 'test-lab-flask', title: 'Demo data', size: 'large' })),
      h('div', { className: 'psd-actions' },
        h('label', { className: 'psd-viewas' }, h(Typography, { variant: 'p4', color: 'muted' }, 'View as'),
          h(Select, { name: 'persona', value: persona, onChange: setPersona, size: 'compact', width: 190, 'aria-label': 'View as' },
            h(SelectItem, { value: 'all' }, 'All roles'),
            Object.keys(LENS).map(k => h(SelectItem, { key: k, value: k }, LENS[k].persona)))),
        h(IconButton, { icon: 'information-circle', size: 'small', color: 'slate', selected: info, 'aria-label': 'Info', title: 'Info, About and Diagnostics', onClick: () => setInfo(!info) }),
        h(IconButton, { icon: 'moon-night-mode', size: 'small', color: 'slate', selected: theme === 'dark', 'aria-label': theme === 'dark' ? 'Light mode' : 'Dark mode', onClick: () => setTheme(theme === 'dark' ? 'light' : 'dark') })));

    let body;
    if (failure) body = h('div', { className: 'psd-body' }, h(AlertPanel, { severity: 'error', icon: 'warning-circle', title: 'Couldn’t load projects', description: `${failure}. Open Info › Diagnostics for the failing call.` }));
    else if (!facts) body = h('div', { className: 'psd-body' }, h(ContextLayout, { icon: 'clock-loading', title: 'Loading projects',
      description: progress ? `Read ${progress.n} of ${progress.of} projects (sessions, jobs, gear rules, reader tasks). Large projects show live totals only.` : 'Listing projects you can see…' }));
    else if (route.view === 'project' && !current) body = h('div', { className: 'psd-body' }, h(ContextLayout, { icon: 'folder-blank', title: 'Project not found', description: 'It may have been removed or you may not have access.' }, h(Button, { onClick: () => go('#projects') }, 'All projects')));
    else if (current && current.f.stub) body = h(StubView, { s: current });
    else if (current) body = h(ProjectView, { s: current, tab, persona, now });
    else body = h(Portfolio, { sums, persona, now, onOpen: open });

    const ctx = { group: siteLabel, viewing: current ? current.f.project.label : 'All projects', persona: persona === 'all' ? 'All roles' : LENS[persona].persona, live, user: boot.user };
    return h('div', { className: 'psd-shell' + (info ? ' with-info' : '') },
      header,
      h('div', { className: 'psd-main' },
        h('main', { className: 'psd-content' }, body,
          h('footer', { className: 'psd-foot' }, `${BUILD.app}/${BUILD.version} · ${live ? 'live harness · ' + boot.site : 'prototype · demo data'} · read-only`)),
        info && h(InfoPanel, { ctx, sel: current && !current.f.stub ? current : null, now, onClose: () => setInfo(false), diag: live ? h(Diagnostics, { log, notes, sample }) : null })));
  }

  function StubView({ s }) {
    const st = s.f.statistics;
    return h('div', { className: 'psd-body' },
      h('div', { className: 'psd-crumb' }, h('a', { href: '#projects' }, 'All projects')),
      h(Typography, { variant: 'h2' }, s.f.project.label),
      h('div', { className: 'psd-statline' }, [['Subjects', st.subjects], ['Sessions', st.sessions], ['Acquisitions', st.acquisitions], ['Acquisition files', st.acquisition_files], ['Analyses', st.analyses], ['Jobs', st.jobs]]
        .map(([k, v]) => h('div', { key: k }, h('b', null, fmtNum(v)), h('span', null, k))), h(SrcMark, { src: 'live' })),
      h(AlertPanel, { severity: 'info', icon: 'information-circle', title: 'Live totals only', description: s.f.stub }));
  }

  async function start() {
    const rootEl = document.getElementById('root');
    const markSrc = document.getElementById('fw-mark').getAttribute('src');
    const params = new URLSearchParams(location.search);
    const embedded = window.top !== window;
    const demo = () => {
      const now = Date.now();
      const raw = window.PSD_DEMO.build(now);
      const facts = raw.projects.map(p => { const rec = raw.byProject[p._id]; const fct = PSDL.buildFacts(rec, now); fct.generated_at = now - rec.snapshotAgeMin * 60000; return fct; });
      raw.projects.forEach((p, i) => { facts[i].live = window.PSD_DEMO.liveDelta(raw.byProject[p._id], facts[i].generated_at, now); });
      const big = window.PSD_DEMO.scaleFacts(now); big.live = window.PSD_DEMO.scaleLive(big, now);
      facts.push(big);
      return { mode: 'demo', now, group: raw.group, facts, options: {}, markSrc };
    };
    if (!embedded || params.has('demo')) { ReactDOM.createRoot(rootEl).render(h(App, { boot: demo() })); return; }
    // Inside Flywheel: never fall back to demo data.
    if (!window.Flywheel) {
      ReactDOM.createRoot(rootEl).render(h('div', { className: 'psd-body' }, h(AlertPanel, { severity: 'error', icon: 'warning-circle', title: 'Flywheel Extension SDK did not load', description: 'No data is shown. Reload; if it persists, check the browser console.' })));
      return;
    }
    try {
      window.FW_CHROME = window.FW_CHROME || { /* Custom Apps note claude/extension-dialog-sizing-note.md */ fullWidth: true, hideHostClose: false,
        initOptions(o) { if (this.hideHostClose) o.hideCloseButton = true; return o; },
        apply(ext) { const d = document.documentElement; d.classList.add('fw-embedded'); if (this.hideHostClose) d.classList.add('fw-own-close');
          if (this.fullWidth && ext && typeof ext.updateViewport === 'function') { try { ext.updateViewport({ width: '100vw' }); } catch (e) { console.warn('updateViewport failed', e); } } } };
      const ext = await Promise.race([
        window.Flywheel.initExtension(FW_CHROME.initOptions({ scope: 'ReadOnly' })),
        new Promise((_, rej) => setTimeout(() => rej(new Error('No answer from Flywheel within 15 s')), 15000)),
      ]);
      FW_CHROME.apply(ext);
      const c = ext.container || {};
      const ctype = c.container_type || c.type || null;
      const cid = c._id || c.id || null;
      const pid = ctype === 'project' ? cid : (c.parents && c.parents.project) || null;
      let site = 'Flywheel';
      try { site = new URL(document.referrer).hostname.split('.')[0] || site; } catch (e) { /* no referrer */ }
      const u = ext.user || {};
      ReactDOM.createRoot(rootEl).render(h(App, { boot: { mode: 'live', ext, now: Date.now(), openedAt: Date.now(), site, projectId: pid,
        user: u._id || u.id || u.email || '—', options: { ...(ext.params || {}) }, markSrc, group: { label: site } } }));
    } catch (e) {
      ReactDOM.createRoot(rootEl).render(h('div', { className: 'psd-body' }, h(AlertPanel, { severity: 'error', icon: 'warning-circle', title: 'Couldn’t connect to Flywheel', description: `${e.message || e}. Close this window and launch the app again.` })));
    }
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start); else start();
})();
