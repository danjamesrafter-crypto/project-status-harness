#!/usr/bin/env python3
"""Build Project Status into one self-contained index.html (dist/index.html)."""
import datetime, json, pathlib, subprocess
ROOT = pathlib.Path(__file__).resolve().parent.parent
S = ROOT / 'src'
VERSION = '0.4.7'

def commit():
    try:
        c = subprocess.check_output(['git', '-C', str(ROOT), 'rev-parse', '--short', 'HEAD'], stderr=subprocess.DEVNULL).decode().strip()
        dirty = subprocess.check_output(['git', '-C', str(ROOT), 'status', '--porcelain', 'src'], stderr=subprocess.DEVNULL).decode().strip()
        return c + ('-dirty' if dirty else '')
    except Exception:
        return 'nogit'

import base64
def icon_font_css(css):
    b64 = base64.b64encode((S / 'Flywheel-Vision-Icons.woff').read_bytes()).decode()
    old = "url(https://cdn.jsdelivr.net/npm/@flywheel-io/vision@22.1.2/assets/fonts/Flywheel-Vision-Icons.woff)"
    assert old in css
    return css.replace(old, f"url(data:font/woff;base64,{b64})")

def safe(js):
    return js.replace('</script', '<\\/script')

build = {'app': 'project-status', 'version': f'{VERSION} ({commit()})', 'mode': 'prototype',
         'built': datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}
html = f"""<!doctype html>
<html lang="en" data-mode="dark" class="vision-dark">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="referrer" content="no-referrer">
<meta name="generator" content="project-status/{VERSION}">
<title>Project Status</title>
<!-- Icon font: Flywheel-Vision-Icons.woff from @flywheel-io/vision 22.1.2 (npm), inlined as a data: URI -->
<style>
{icon_font_css((S / 'vision.css').read_text())}
{(S / 'icon-glyphs.css').read_text()}
{(S / 'app.css').read_text()}
</style>
<script src="https://cdn.jsdelivr.net/npm/react@18.3.1/umd/react.production.min.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/react-dom@18.3.1/umd/react-dom.production.min.js" crossorigin="anonymous"></script>
</head>
<body>
{(S / 'mark.html').read_text()}
<div id="root"></div>
<script>window.PSD_BUILD = {json.dumps(build)};</script>
<script>{safe((S / 'sdk.js').read_text())}</script>
<script>{safe((S / 'vision-subset.js').read_text())}</script>
<script>{safe((S / 'demo.js').read_text())}</script>
<script>{safe((S / 'logic.js').read_text())}</script>
<script>{safe((S / 'live.js').read_text())}</script>
<script>{safe((S / 'app.js').read_text())}</script>
</body>
</html>
"""
out = ROOT / 'dist' / 'index.html'
out.parent.mkdir(exist_ok=True)
out.write_text(html)
print(out, len(html), build['version'])
