/* src/live.js */
/* Project Status — live adapter for the extension-app harness.
 * Reads Flywheel through the Extension SDK (ReadOnly scope, GET only) and builds the same facts document
 * the snapshot gear will write. Until that gear exists, facts are computed in the browser, and only for
 * projects small enough to page through safely (size guard from project.statistics). Bigger projects show
 * live totals only, marked "Needs snapshot gear". Every call is logged for the Diagnostics view. */
(function () {
  'use strict';
  const TASK_COLUMNS = 'task_id,created,modified,status,priority,protocol_label,protocol_id,assignee,parents,due_date,subcategory,read_number,transitions,parent_ref.type,parent_ref.id';
  const PAGE = 100, JOB_PAGE = 500;
  const rows = res => (Array.isArray(res) ? res : (res && res.results) || []);
  const totalOf = res => (res && !Array.isArray(res) && res.total != null ? res.total : null);
  const pick = (o, path) => String(path || '').split('.').reduce((v, k) => (v == null ? v : v[k]), o);

  function makeApi(ext, log) {
    return async function api(path, params) {
      const t0 = performance.now();
      const entry = { at: Date.now(), method: 'GET', path, params: params || null };
      try {
        const res = await Promise.race([
          ext.apiRequest('GET', path, params || undefined),
          new Promise((_, rej) => setTimeout(() => rej(new Error('Timed out after 30 s')), 30000)),
        ]);
        entry.ok = true; entry.ms = Math.round(performance.now() - t0);
        entry.rows = Array.isArray(res) ? res.length : res && Array.isArray(res.results) ? res.results.length : null;
        entry.total = totalOf(res);
        if (!log.sample[path.replace(/[0-9a-f]{24}/g, '{id}')]) log.sample[path.replace(/[0-9a-f]{24}/g, '{id}')] = Array.isArray(res) ? res[0] : res && res.results ? res.results[0] : res;
        log(entry);
        return res;
      } catch (e) {
        entry.ok = false; entry.ms = Math.round(performance.now() - t0);
        entry.error = (e && (e.message || e.statusText)) || String(e);
        entry.status = (e && (e.status || e.statusCode)) || null;
        log(entry);
        throw e;
      }
    };
  }

  async function loadTasks(api, pid, note) {
    const seen = new Map();
    let filter = `parents.project=${pid}`, skip = 0, total = null, pages = 0;
    for (;;) {
      const params = { limit: PAGE, skip, sort: 'created:desc,task_id:asc', columns: TASK_COLUMNS };
      if (filter) params.filter = filter;
      let res;
      try { res = await api('/api/tasks/reader', params); }
      catch (e) {
        if (filter && skip === 0) { note('Reader tasks: project filter rejected; loading all visible tasks and filtering here.'); filter = null; continue; }
        throw e;
      }
      const batch = rows(res);
      if (totalOf(res) != null) total = totalOf(res);
      for (const t of batch) seen.set(t._id ?? t.id, t);
      skip += batch.length; pages++;
      if (!batch.length || batch.length < PAGE || (total != null && skip >= total) || pages > 100) break;
    }
    return [...seen.values()].filter(t => !t.parents || !t.parents.project || t.parents.project === pid);
  }

  async function loadJobs(api, pid, note, maxJobs) {
    const seen = new Map();
    let page = 1, total = null;
    for (;;) {
      const res = await api('/api/jobs', { filter: `parents.project=${pid}`, limit: JOB_PAGE, page, sort: 'created:desc', include_parent_info: true });
      const batch = rows(res);
      if (totalOf(res) != null) total = totalOf(res);
      for (const j of batch) seen.set(j.id || j._id, j);
      if (!batch.length || batch.length < JOB_PAGE || (total != null && seen.size >= total) || seen.size >= maxJobs) break;
      page++;
    }
    const all = [...seen.values()];
    const mine = all.filter(j => !j.parents || !j.parents.project || j.parents.project === pid);
    if (mine.length < all.length) note(`Jobs: ${all.length - mine.length} jobs from other projects came back and were dropped (filter ignored?).`);
    if (total != null && total > mine.length) note(`Jobs: loaded ${mine.length} of ${total}; facts cover the newest ${mine.length}.`);
    return mine;
  }

  // Map raw Flywheel records onto the shapes buildFacts() expects.
  function normSession(s, o) {
    const subj = s.subject || {};
    return { _id: s._id || s.id, label: s.label,
      subject: { _id: subj._id || subj.id || s.subject_id || null, code: subj.code || subj.label || subj._id || '—' },
      created: s.created, timestamp: s.timestamp,
      satisfies_template: s.satisfies_template, // undefined when the server does not send it → counted as satisfied; flagged in notes
      info: { site: pick(s, o.siteField) || pick(s, 'info.site') || '—', visit: pick(s, o.visitField) || s.label } };
  }
  function normJob(j, gearsById) {
    const gi = j.gear_info || {};
    const g = gi.name ? gi : gearsById.get(j.gear_id) || {};
    const pr = j.profile || {};
    // The job list has no parents/transitions/profile (r6nvg8, 2026-11-23). Parent ids come from include_parent_info
    // (shape unverified: accept {session:{_id}} or {session:'id'}) or from destination when it is a session.
    const pi = j.parent_info || {};
    const idOf = v => (v && typeof v === 'object' ? v._id || v.id : v) || null;
    const dest = j.destination || {};
    const parents = j.parents || { project: idOf(pi.project), subject: idOf(pi.subject), session: idOf(pi.session) || (dest.type === 'session' ? dest.id : null), acquisition: idOf(pi.acquisition) || (dest.type === 'acquisition' ? dest.id : null) };
    return { id: j.id || j._id, gear_info: { name: g.name || gi.name || j.gear_id || 'unknown', version: g.version || gi.version || '' },
      state: j.state, created: j.created, transitions: j.transitions || {},
      profile: { elapsed_time_ms: pr.elapsed_time_ms || pr.total_time_ms || null },
      failure_reason: j.failure_reason || (j.state === 'failed' ? null : undefined),
      origin: j.origin || { type: 'unknown', id: null }, parents };
  }

  /** Load one project's raw records and build its facts. Returns { facts } or { tooBig } with the reason. */
  async function loadProject(api, project, ctx) {
    const o = ctx.options, notes = [];
    const note = m => notes.push(m);
    const pid = project._id;
    const stats = project.statistics || {};
    if ((stats.sessions || 0) > o.maxSessions || (stats.jobs || 0) > o.maxJobs) {
      return { tooBig: `${(stats.sessions || 0).toLocaleString()} sessions / ${(stats.jobs || 0).toLocaleString()} jobs is above the browser limit (${o.maxSessions.toLocaleString()} / ${o.maxJobs.toLocaleString()}). Needs the snapshot gear.`, notes };
    }
    const [sessionsRes, jobsRes, rulesRes, tasksRes] = await Promise.allSettled([
      api(`/api/projects/${pid}/sessions`),
      loadJobs(api, pid, note, o.maxJobs),
      api(`/api/projects/${pid}/rules`),
      loadTasks(api, pid, note),
    ]);
    const unavailable = {};
    const sessions = sessionsRes.status === 'fulfilled' ? rows(sessionsRes.value).map(s => normSession(s, o)) : (unavailable.data = `Sessions: ${sessionsRes.reason && sessionsRes.reason.message}`, []);
    const jobs = jobsRes.status === 'fulfilled' ? jobsRes.value.map(j => normJob(j, ctx.gearsById)) : (unavailable.compute = `Jobs: ${jobsRes.reason && jobsRes.reason.message}`, []);
    const rules = rulesRes.status === 'fulfilled' ? rows(rulesRes.value).map(r => ({ _id: r._id, name: r.name || 'Gear rule', disabled: !!r.disabled,
      _gear: (ctx.gearsById.get(r.gear_id) || {}).name || r.gear_id || 'unknown' })) : (note(`Gear rules: ${rulesRes.reason && rulesRes.reason.message}`), []);
    const tasks = tasksRes.status === 'fulfilled' ? tasksRes.value : (note(`Reader tasks: ${tasksRes.reason && tasksRes.reason.message}`), []);
    if (sessions.length && sessions.every(s => s.satisfies_template === undefined)) note('Sessions: satisfies_template not returned; template completeness shows 100% until the snapshot gear computes it. (verify field)');
    const primary = tasks.filter(t => t.subcategory !== 'adjudicator');
    const tasked = new Set(primary.map(t => t.parents && t.parents.session)).size;
    const rec = { project: { _id: pid, label: project.label, info: { study_code: project.label, indication: (project.info && project.info.indication) || '—',
        tier: (project.info && project.info.tier) || '—', criteria: (project.info && project.info.criteria) || '—', group: project.group } },
      statistics: stats, sessions, jobs, rules, tasks,
      spec: { readsPerSession: tasked ? Math.round(primary.length / tasked) : 0 } };
    if (stats.sessions != null && stats.jobs == null) rec.statistics = { ...stats, jobs: jobs.length };
    if (stats.sessions == null) { rec.statistics = { subjects: new Set(sessions.map(x => x.subject._id)).size, sessions: sessions.length, acquisitions: null, acquisition_files: null, analyses: null, jobs: jobs.length }; note('Project statistics not returned; totals counted from loaded records.'); }
    const facts = window.PSD.buildFacts(rec, ctx.now, o);
    facts.live = window.PSD_LIVE_DELTA(rec, ctx.openedAt, Date.now());
    facts.live.label = 'Since this page opened';
    facts.unavailable = unavailable;
    facts.notes = notes;
    facts.source = 'browser';
    return { facts, rec, notes };
  }

  /** Load every project the user can see; facts for the small ones, live totals for the rest. */
  async function loadSite(ext, ctx, log, onProgress) {
    const api = makeApi(ext, log);
    const siteNotes = [];
    let list;
    try { list = rows(await api('/api/projects', { exhaustive: true })); } catch (e) { siteNotes.push('Projects: exhaustive list refused; showing your projects only.'); list = rows(await api('/api/projects')); }
    let gears = [];
    try { gears = rows(await api('/api/gears')); } catch (e) { siteNotes.push(`Gears list: ${e.message || e}; gear names fall back to ids.`); }
    ctx.gearsById = new Map(gears.map(g => [g._id || g.id, { name: (g.gear && g.gear.name) || g.name, version: (g.gear && g.gear.version) || g.version }]));
    // statistics: from the list if present, else per project (verified on GET /api/projects/{id})
    // Core reads project.stats (mapped to "statistics" in its UI). Ask for it explicitly; fall back to the list's counts.
    const withStats = p => ({ ...p, statistics: p.statistics || p.stats || (p.session_count != null ? { subjects: p.subject_count, sessions: p.session_count, acquisitions: null, acquisition_files: null, analyses: null, jobs: null } : undefined) });
    const projects = await Promise.all(list.map(async p => {
      if (p.statistics || p.stats) return withStats(p);
      const full = await api(`/api/projects/${p._id}`, { stats: true }).catch(() => null);
      return withStats({ ...p, ...(full || {}) });
    }));
    const out = [];
    const queue = [...projects];
    const workers = Array.from({ length: Math.min(3, queue.length) }, async () => {
      while (queue.length) {
        const p = queue.shift();
        try {
          const r = await loadProject(api, p, ctx);
          out.push({ project: p, ...r });
        } catch (e) { out.push({ project: p, error: e.message || String(e) }); }
        onProgress && onProgress(out.length, projects.length);
      }
    });
    await Promise.all(workers);
    return { results: out, siteNotes, api };
  }

  /** Cheap live refresh for the open project: statistics only (one call). */
  async function refreshStats(api, pid) {
    const p = await api(`/api/projects/${pid}`, { stats: true });
    return p && (p.statistics || p.stats || (p.session_count != null ? { subjects: p.subject_count, sessions: p.session_count } : null));
  }

  window.PSD_LIVE = { loadSite, loadProject, refreshStats, makeApi };
})();
