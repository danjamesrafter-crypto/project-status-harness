/* src/logic.js */
/* Project Status — pure logic (no DOM, no Flywheel).
 *
 * Two halves, because a real project can hold ~165k sessions and ~5.9M jobs (GNE, 2026-11-20):
 *  1. buildFacts(rec, now)  — GEAR SIDE. Streams raw sessions / jobs / tasks once and emits a small,
 *     JSON-plain facts document (counts, rates, series, top-N rows + totals). The browser never sees raw records.
 *     In the prototype it runs in the browser on the small demo studies to stand in for the snapshot gear.
 *  2. assess(facts, opts, now) — APP SIDE. Turns facts into health calls and the attention list using
 *     the app's thresholds. Thresholds are rates and percentiles, so they hold at any project size.
 */
(function () {
  'use strict';
  const DAY = 86400000, HOUR = 3600000, MIN = 60000;
  const TOP_N = 50;
  const ts = v => (v ? (typeof v === 'number' ? v : Date.parse(v)) : null);
  const dueTs = d => (d ? Date.parse(String(d).slice(0, 10) + 'T23:59:59') : null); // calendar day, local end of day
  const median = a => quantile(a, 0.5);
  function quantile(a, q) { if (!a.length) return null; const s = [...a].sort((x, y) => x - y); const i = (s.length - 1) * q; const lo = Math.floor(i), hi = Math.ceil(i); return s[lo] + (s[hi] - s[lo]) * (i - lo); }
  const weekStart = t => { const d = new Date(t); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return d.getTime(); };
  const dayStart = t => { const d = new Date(t); d.setHours(0, 0, 0, 0); return d.getTime(); };
  // DST-safe calendar keys: normalise each step instead of adding 7 * DAY to a key
  const weekKeys = (now, n, includeCurrent) => { const out = []; for (let i = includeCurrent ? n - 1 : n; i >= (includeCurrent ? 0 : 1); i--) out.push(weekStart(now - i * 7 * DAY)); return out; };
  const natural = (a, b) => String(a).localeCompare(String(b), undefined, { numeric: true });
  const top = (arr, n) => arr.slice(0, n || TOP_N);

  const DEFAULTS = {
    templateWatch: 0.95, templateAct: 0.85,      // share of sessions satisfying the session template
    staleUploadDays: 21,                          // an active site with no upload for this long
    overdueActShare: 0.10, overdueActMin: 5,      // overdue / open reads (and at least this many) → Action
    overdueWatchShare: 0.02,                      // overdue / open reads → Watch
    stalledWatchShare: 0.02,                      // stalled / open reads → Watch
    smallQueue: 50,                               // below this many open reads, any overdue/stalled read → Watch
    stalledAfterDays: 7,
    failWatch: 0.05, failAct: 0.15,               // failed / finished jobs in the window
    gearMinRuns: 10,                              // a gear needs this many finished runs before it is judged
    queueP95WatchMin: 60,                         // p95 wait of jobs pending now
    weeks: 12,
    windowDays: 7,
    maxSessions: 3000, maxJobs: 30000,          // browser-compute guard (live harness, until the snapshot gear exists)
    siteField: 'info.site', visitField: 'info.visit',
  };

  const SEV = { act: 3, watch: 2, ok: 1, info: 1, na: 0, off: 0 };
  const worstOf = a => a.reduce((x, y) => (SEV[y] > SEV[x] ? y : x), 'na');

  // ================================================================ 1. FACTS (gear side)
  function dataFacts(sessions, now, o) {
    const subjects = new Set(sessions.map(s => s.subject && (s.subject._id || s.subject.code)));
    const ok = sessions.filter(s => s.satisfies_template !== false).length;
    const last = sessions.reduce((m, s) => Math.max(m, ts(s.created) || 0), 0) || null;
    const recent = sessions.filter(s => ts(s.created) > now - o.windowDays * DAY).length;
    const bySite = new Map();
    for (const s of sessions) {
      const site = (s.info && s.info.site) || '—';
      const e = bySite.get(site) || { site, subjects: new Set(), sessions: 0, ok: 0, last: 0 };
      e.subjects.add(s.subject && s.subject.code); e.sessions++; if (s.satisfies_template !== false) e.ok++;
      e.last = Math.max(e.last, ts(s.created) || 0);
      bySite.set(site, e);
    }
    const sites = [...bySite.values()].map(e => ({ site: e.site, subjects: e.subjects.size, sessions: e.sessions, template_ok: e.ok, last: e.last }))
      .sort((a, b) => natural(a.site, b.site));
    const weeks = new Map(weekKeys(now, o.weeks, true).map(w => [w, 0]));
    for (const s of sessions) { const w = weekStart(ts(s.created)); if (weeks.has(w)) weeks.set(w, weeks.get(w) + 1); }
    const missing = sessions.filter(s => s.satisfies_template === false).map(s => ({
      id: s._id, subject: s.subject && s.subject.code, visit: (s.info && s.info.visit) || s.label, site: s.info && s.info.site,
      created: ts(s.created), missing: (s.info && s.info._missing && s.info._missing.join(', ')) || 'Session template not satisfied',
    })).sort((a, b) => b.created - a.created);
    return { subjects: subjects.size, sessions: sessions.length, template_ok: ok, last, recent,
      sites, sites_total: sites.length, missing: top(missing), missing_total: missing.length,
      weekly: [...weeks].map(([week, n]) => ({ week, n })) };
  }

  function taskFacts(tasks, now, o, readsPerSession) {
    if (!tasks.length && !readsPerSession) return { used: false };
    const primary = tasks.filter(t => t.subcategory !== 'adjudicator' && t.status !== 'cancelled');
    const adj = tasks.filter(t => t.subcategory === 'adjudicator' && t.status !== 'cancelled' && t.status !== 'completed');
    const enrich = t => {
      const due = dueTs(t.due_date);
      const idle = (now - (ts(t.modified) || ts(t.created))) / DAY;
      return { id: t._id, task_id: t.task_id, status: t.status, due, created: ts(t.created),
        overdue: t.status !== 'completed' && due != null && now > due, overdueDays: due ? Math.floor((now - due) / DAY) : 0,
        stalled: t.status === 'in_progress' && idle > o.stalledAfterDays, ageDays: (now - ts(t.created)) / DAY,
        reader: t.assignee ? (t.assignee.type === 'user' ? t.assignee.id.split('@')[0] : 'Pool') : 'Unassigned', assigned: !!t.assignee,
        _t: t };
    };
    const all = primary.map(enrich);
    const done = all.filter(t => t.status === 'completed');
    const open = all.filter(t => t.status !== 'completed');
    const overdue = open.filter(t => t.overdue).sort((a, b) => b.overdueDays - a.overdueDays);
    const byReader = new Map();
    for (const t of all) {
      const e = byReader.get(t.reader) || { reader: t.reader, total: 0, completed: 0, open: 0, overdue: 0, stalled: 0, turn: [] };
      e.total++;
      if (t.status === 'completed') { const tr = t._t.transitions || {}; const a = ts(tr.in_progress) || t.created; const b = ts(tr.completed) || ts(t._t.modified); e.completed++; if (a && b) e.turn.push((b - a) / DAY); }
      else { e.open++; if (t.overdue) e.overdue++; if (t.stalled) e.stalled++; }
      byReader.set(t.reader, e);
    }
    const readers = [...byReader.values()].map(({ turn, ...e }) => ({ ...e, turnaround_days: median(turn) })).sort((a, b) => b.open - a.open || natural(a.reader, b.reader));
    const weeks = new Map(weekKeys(now, o.weeks - 1, false).map(w => [w, 0])); // current partial week excluded
    for (const t of done) { const c = ts(t._t.transitions && t._t.transitions.completed) || ts(t._t.modified); const w = weekStart(c); if (weeks.has(w)) weeks.set(w, weeks.get(w) + 1); }
    const buckets = [[0, 7, '0–7 d'], [7, 14, '8–14 d'], [14, 30, '15–30 d'], [30, 1e9, '> 30 d']];
    const strip = ({ _t, ...r }) => r;
    return { used: true, total: all.length, completed: done.length, open: open.length,
      overdue: top(overdue).map(strip), overdue_total: overdue.length,
      stalled_total: open.filter(t => t.stalled).length, unassigned: open.filter(t => !t.assigned).length,
      readers: top(readers, 200), readers_total: readers.length,
      weekly: [...weeks].map(([week, n]) => ({ week, n })),
      age: buckets.map(([a, b, label]) => ({ bucket: label, n: open.filter(t => t.ageDays >= a && t.ageDays < b).length })),
      adj_open: adj.length, adj_blocked: adj.filter(t => t.status === 'blocked').length };
  }

  function computeFacts(jobs, rules, now, o) {
    const since = now - o.windowDays * DAY;
    const finishedAt = j => ts(j.transitions && (j.transitions.complete || j.transitions.failed || j.transitions.cancelled));
    const win = jobs.filter(j => ts(j.created) > since);
    const finished = win.filter(j => j.state === 'complete' || j.state === 'failed');
    const failed = win.filter(j => j.state === 'failed');
    const pending = jobs.filter(j => j.state === 'pending').map(j => ({ id: j.id, gear: j.gear_info.name, version: j.gear_info.version,
      launched_by: j.origin.type === 'rule' ? 'Gear rule' : j.origin.id, wait_min: (now - ts(j.created)) / MIN })).sort((a, b) => b.wait_min - a.wait_min);
    const waits = win.filter(j => j.transitions && j.transitions.running).map(j => (ts(j.transitions.running) - ts(j.created)) / MIN);
    const byGear = new Map();
    for (const j of jobs) {
      const k = j.gear_info.name;
      const e = byGear.get(k) || { gear: k, versions: new Map(), runs: 0, failed: 0, finished: 0, dur: [], reasons: new Map(), last: 0, lastVersion: j.gear_info.version };
      if (ts(j.created) >= e.last) { e.last = ts(j.created); e.lastVersion = j.gear_info.version; }
      if (ts(j.created) > since) {
        e.runs++; e.versions.set(j.gear_info.version, (e.versions.get(j.gear_info.version) || 0) + 1);
        if (j.state === 'complete' || j.state === 'failed') { e.finished++; if (j.profile && j.profile.elapsed_time_ms) e.dur.push(j.profile.elapsed_time_ms / MIN); }
        if (j.state === 'failed') { e.failed++; const r = j.failure_reason || 'Unknown'; e.reasons.set(r, (e.reasons.get(r) || 0) + 1); }
      }
      byGear.set(k, e);
    }
    const ruleByGear = new Map(rules.map(r => [r._gear || r.name, r]));
    const gears = [...byGear.values()].map(e => {
      const rule = ruleByGear.get(e.gear);
      return { gear: e.gear, versions: [...e.versions].sort((a, b) => b[1] - a[1]).map(([version, runs]) => ({ version, runs })), last_version: e.lastVersion,
        runs: e.runs, finished: e.finished, failed: e.failed, median_min: median(e.dur),
        reasons: [...e.reasons].sort((a, b) => b[1] - a[1]).slice(0, 3).map(([reason, n]) => ({ reason, n })),
        rule: rule ? (rule.disabled ? 'disabled' : 'on') : 'manual' };
    });
    for (const r of rules) if (!byGear.has(r._gear)) gears.push({ gear: r._gear, versions: [], last_version: null, runs: 0, finished: 0, failed: 0, median_min: null, reasons: [], rule: r.disabled ? 'disabled' : 'on' });
    const days = new Map();
    for (let i = 13; i >= 0; i--) { const d = dayStart(now - i * DAY); days.set(d, { day: d, complete: 0, failed: 0 }); } // DST-safe keys
    for (const j of jobs) { if (j.state !== 'complete' && j.state !== 'failed') continue; const d = dayStart(finishedAt(j) || ts(j.created)); const e = days.get(d); if (e) e[j.state]++; }
    const latest = new Map();
    for (const j of jobs) { const k = `${j.parents.session}|${j.gear_info.name}`; const p = latest.get(k); if (!p || ts(j.created) > ts(p.created)) latest.set(k, j); }
    const unresolved = [...latest.values()].filter(j => j.state === 'failed')
      .map(j => ({ id: j.id, gear: j.gear_info.name, version: j.gear_info.version, reason: j.failure_reason || null,
        launched_by: j.origin.type === 'rule' ? 'Gear rule' : j.origin.id, at: finishedAt(j) || ts(j.created) }))
      .sort((a, b) => b.at - a.at);
    return { jobs_window: win.length, finished: finished.length, failed: failed.length,
      running: jobs.filter(j => j.state === 'running').length,
      pending: top(pending), pending_total: pending.length,
      queue_p95_min: quantile(pending.map(p => p.wait_min), 0.95), queue_max_min: pending.length ? pending[0].wait_min : null,
      median_wait_min: median(waits),
      hours: finished.reduce((a, j) => a + ((j.profile && j.profile.elapsed_time_ms) || 0), 0) / HOUR,
      gears, daily: [...days.values()], unresolved: top(unresolved), unresolved_total: unresolved.length,
      rules: rules.map(r => ({ name: r.name, gear: r._gear || r.name, disabled: !!r.disabled })) };
  }

  function pipelineFacts(sessions, jobs, tasks, gearsExpected, readsPerSession, rules) {
    const latest = new Map();
    for (const j of jobs) { const k = `${j.parents.session}|${j.gear_info.name}`; const p = latest.get(k); if (!p || ts(j.created) > ts(p.created)) latest.set(k, j); }
    const readsBySession = new Map();
    for (const t of tasks) { if (t.subcategory === 'adjudicator' || t.status === 'cancelled') continue; const s = t.parents && t.parents.session; const e = readsBySession.get(s) || { n: 0, done: 0 }; e.n++; if (t.status === 'completed') e.done++; readsBySession.set(s, e); }
    // A rule gear with no job anywhere in the project would zero the step; report it instead (r6nvg8 finding, 2026-11-23).
    const ran = new Set(jobs.map(j => j.gear_info.name));
    const never = gearsExpected.filter(g => !ran.has(g));
    gearsExpected = gearsExpected.filter(g => ran.has(g));
    const coverage = gearsExpected.map(g => ({ gear: g, complete: sessions.filter(s => { const j = latest.get(`${s._id}|${g}`); return j && j.state === 'complete'; }).length }));
    const st = { uploaded: sessions.length, template: 0, processed: 0, tasked: 0, read: 0, never_ran: never, coverage, flow: ruleFlow(sessions, jobs, latest, rules || []) };
    for (const s of sessions) {
      if (s.satisfies_template === false) continue; st.template++;
      if (!gearsExpected.every(g => { const j = latest.get(`${s._id}|${g}`); return j && j.state === 'complete'; })) continue; st.processed++;
      if (!readsPerSession) continue;
      const r = readsBySession.get(s._id); if (!r) continue; st.tasked++;
      if (r.done >= Math.max(readsPerSession, r.n)) st.read++;
    }
    return st;
  }

  /** Rule flow: one node per rule gear, where each session's latest job of that gear stands.
   *  Order is inferred, not declared: median minutes from a session's first job to this gear's first job (approximate). */
  function ruleFlow(sessions, jobs, latest, rules) {
    const byGear = new Map();
    for (const r of rules) { const g = r._gear || r.name; const e = byGear.get(g) || { gear: g, rules: [], disabled: true }; e.rules.push(r.name); if (!r.disabled) e.disabled = false; byGear.set(g, e); }
    const first = new Map(), firstGear = new Map();
    for (const j of jobs) { const sid = j.parents.session; if (!sid) continue; const t = ts(j.created);
      if (!(first.get(sid) <= t)) first.set(sid, t);
      const k = `${sid}|${j.gear_info.name}`; if (!(firstGear.get(k) <= t)) firstGear.set(k, t); }
    const ids = new Set(sessions.map(x => x._id));
    return [...byGear.values()].map(e => {
      const c = { complete: 0, failed: 0, running: 0, none: 0 }, offs = [];
      for (const sid of ids) { const j = latest.get(`${sid}|${e.gear}`);
        if (!j) { c.none++; continue; }
        if (j.state === 'complete') c.complete++; else if (j.state === 'failed' || j.state === 'cancelled') c.failed++; else c.running++;
        const f = firstGear.get(`${sid}|${e.gear}`); if (f != null) offs.push((f - first.get(sid)) / MIN); }
      offs.sort((a, b) => a - b);
      const ran = c.complete + c.failed + c.running;
      return { gear: e.gear, rules: e.rules, disabled: e.disabled, sessions: ids.size, ...c, order_min: offs.length ? offs[offs.length >> 1] : null, state: e.disabled ? 'disabled' : ran ? 'enabled' : 'never_ran' };
    }).sort((a, b) => (a.state === 'disabled') - (b.state === 'disabled') || (a.order_min == null) - (b.order_min == null) || (a.order_min || 0) - (b.order_min || 0) || a.gear.localeCompare(b.gear));
  }

  /** GEAR SIDE: raw records → facts document (what project-status.summary.json would hold). */
  function buildFacts(rec, now, opts) {
    const o = { ...DEFAULTS, ...(opts || {}) };
    const gearsExpected = rec.rules.filter(r => !r.disabled).map(r => r._gear || r.name);
    const tasks = taskFacts(rec.tasks, now, o, rec.spec.readsPerSession);
    return {
      schema: 'project-status/facts@1', generated_at: now, window_days: o.windowDays,
      project: { _id: rec.project._id, label: rec.project.label, info: rec.project.info },
      statistics: rec.statistics, // from GET /api/projects/{id} → statistics (verified on r6nvg8, 2026-11-20)
      data: dataFacts(rec.sessions, now, o), tasks, compute: computeFacts(rec.jobs, rec.rules, now, o),
      pipeline: { ...pipelineFacts(rec.sessions, rec.jobs, rec.tasks, gearsExpected, rec.spec.readsPerSession, rec.rules), reads: !!tasks.used },
    };
  }

  // ================================================================ 2. ASSESS (app side)
  function assess(f, opts, now) {
    const o = { ...DEFAULTS, ...(opts || {}) };
    if (f.stub) return { stub: true, health: 'na', data: { health: 'na', share: null, sites: [], stale: [] }, tasks: { health: 'na', share: null },
      compute: { health: 'na', rate: null, gears: [], disabled: [], queueSlow: false }, steps: [], attention: [], options: o };
    const pct = v => `${(Math.round(v * 1000) / 10).toLocaleString(undefined, { maximumFractionDigits: 1 })}%`;
    const plural = (n, w) => `${n.toLocaleString()} ${w}${n === 1 ? '' : 's'}`;
    const d = f.data, t = f.tasks, c = f.compute;

    // data
    const share = d.sessions ? d.template_ok / d.sessions : null;
    const sites = d.sites.map(s => {
      const sh = s.sessions ? s.template_ok / s.sessions : null, idle = (now - s.last) / DAY;
      return { ...s, id: s.site, share: sh, idle_days: idle,
        health: sh != null && sh < o.templateAct ? 'act' : (sh != null && sh < o.templateWatch) || idle > o.staleUploadDays ? 'watch' : 'ok' };
    });
    const stale = sites.filter(s => s.idle_days > o.staleUploadDays && s.sessions > 0).sort((a, b) => b.idle_days - a.idle_days);
    const dataH = !d.sessions ? 'watch' : share < o.templateAct ? 'act' : share < o.templateWatch || stale.length ? 'watch' : 'ok';

    // tasks
    let tasksH = 'na', tShare = null;
    if (t.used) {
      tShare = t.total ? t.completed / t.total : null;
      const od = t.open ? t.overdue_total / t.open : 0, stl = t.open ? t.stalled_total / t.open : 0;
      const small = t.open < o.smallQueue;
      tasksH = !t.total ? 'watch'
        : t.overdue_total >= o.overdueActMin && od >= o.overdueActShare ? 'act'
        : od >= o.overdueWatchShare || stl >= o.stalledWatchShare || (small && (t.overdue_total || t.stalled_total)) ? 'watch' : 'ok';
    }

    // compute
    const rate = c.finished ? c.failed / c.finished : null;
    const gears = c.gears.map(g => {
      const r = g.finished ? g.failed / g.finished : null;
      const judged = r != null && g.finished >= o.gearMinRuns;
      return { ...g, id: g.gear, rate: r,
        version_text: g.versions.length > 1 ? g.versions.map(v => `${v.version} (${v.runs.toLocaleString()})`).join(' · ') : (g.versions[0] && g.versions[0].version) || g.last_version || '—',
        top_reason: g.reasons.length ? `${g.reasons[0].reason} (${g.reasons[0].n.toLocaleString()})` : '—',
        health: judged && r >= o.failAct ? 'act' : judged && g.failed >= 2 && r >= o.failWatch ? 'watch' : g.rule === 'disabled' ? 'watch' : 'ok' };
    }).sort((a, b) => SEV[b.health] - SEV[a.health] || (b.rate || 0) - (a.rate || 0));
    const disabled = c.rules.filter(r => r.disabled);
    const queueSlow = c.queue_p95_min != null && c.queue_p95_min > o.queueP95WatchMin;
    const gearH = worstOf(gears.map(g => g.health));
    const computeH = (rate != null && rate >= o.failAct) || gearH === 'act' ? 'act'
      : (rate != null && rate >= o.failWatch) || gearH === 'watch' || queueSlow || disabled.length ? 'watch' : 'ok';

    // pipeline
    const p = f.pipeline;
    const steps = [
      { key: 'uploaded', label: 'Uploaded', n: p.uploaded, owner: 'data' },
      { key: 'template', label: 'Template complete', n: p.template, owner: 'data' },
      { key: 'processed', label: 'Pipeline complete', n: p.processed, owner: 'compute' },
    ];
    if (p.reads) steps.push({ key: 'tasked', label: 'Tasked for read', n: p.tasked, owner: 'tasks' }, { key: 'read', label: 'Reads complete', n: p.read, owner: 'tasks' });

    // attention
    const a = [];
    const add = (lens, sev, title, detail, go) => a.push({ id: `${lens}-${a.length}`, lens, sev, title, detail, go });
    if (d.missing_total) add('data', share < o.templateAct ? 'act' : share < o.templateWatch ? 'watch' : 'info',
      `${plural(d.missing_total, 'session')} missing required data`, `${pct(share)} of sessions satisfy the session template (target ≥ ${pct(o.templateWatch)}).`, 'data');
    stale.slice(0, 5).forEach(s => add('data', 'watch', `No uploads from site ${s.site} in ${Math.floor(s.idle_days)} days`, `Last upload ${new Date(s.last).toLocaleDateString()}; ${plural(s.subjects, 'subject')}.`, 'data'));
    if (stale.length > 5) add('data', 'watch', `${stale.length - 5} more sites silent for ${o.staleUploadDays}+ days`, 'See the Sites table on the Data tab.', 'data');
    if (t.used) {
      if (t.overdue_total) add('tasks', tasksH === 'act' ? 'act' : 'watch', `${plural(t.overdue_total, 'read')} overdue`,
        `${pct(t.overdue_total / Math.max(1, t.open))} of open reads. Oldest ${t.overdue[0].overdueDays} days past due (${t.overdue[0].reader}).`, 'tasks');
      if (t.stalled_total) add('tasks', 'watch', `${plural(t.stalled_total, 'read')} stalled`, `In progress with no activity for more than ${o.stalledAfterDays} days.`, 'tasks');
      if (t.adj_blocked) add('tasks', 'info', `${plural(t.adj_blocked, 'adjudication')} waiting on comparison`, 'Created up front as blocked; opens when both primary reads finish.', 'tasks');
      const gap = p.processed - p.tasked;
      if (gap > 0) add('tasks', gap > Math.max(10, p.processed * 0.05) ? 'watch' : 'info', `${plural(gap, 'processed session')} not yet tasked for read`, 'Pipeline complete, no reader task created.', 'tasks');
    }
    gears.filter(g => (g.health === 'act' || g.health === 'watch') && g.rate != null && g.finished >= o.gearMinRuns)
      .forEach(g => add('compute', g.health, `${g.gear} failing ${pct(g.rate)} (last ${f.window_days} d)`, `${g.failed.toLocaleString()} of ${g.finished.toLocaleString()} runs · top cause: ${g.top_reason}.`, 'compute'));
    disabled.forEach(r => add('compute', 'watch', `Gear rule "${r.name}" is disabled`, 'New sessions are not being processed by this gear.', 'compute'));
    if (queueSlow) add('compute', 'watch', `Queue p95 wait ${Math.round(c.queue_p95_min)} min`, `${plural(c.pending_total, 'job')} pending; longest ${Math.round(c.queue_max_min)} min.`, 'compute');
    (p.never_ran || []).forEach(g => add('compute', 'watch', `Rule gear ${g} has never run here`, 'Its rule is enabled but no job exists in this project; left out of Pipeline complete.', 'compute'));
    (p.coverage || []).filter(c2 => c2.complete < p.template).sort((x, y) => x.complete - y.complete).slice(0, 3)
      .forEach(c2 => add('compute', 'info', `${c2.gear} complete on ${c2.complete} of ${p.template} sessions`, 'Latest run per session; sessions missing it hold back Pipeline complete.', 'compute'));
    if (c.unresolved_total) add('compute', 'info', `${plural(c.unresolved_total, 'failed job')} not yet re-run`, 'Latest run of that gear on the session failed.', 'compute');
    a.sort((x, y) => SEV[y.sev] - SEV[x.sev]);

    const un = f.unavailable || {};
    const dH = un.data ? 'off' : dataH, cH = un.compute ? 'off' : computeH;
    const stepsShown = un.compute ? steps.slice(0, 2) : steps;
    const att = a.filter(x => !(un.compute && x.lens === 'compute') && !(un.data && x.lens === 'data'));
    return { health: worstOf([dH, tasksH, cH]), unavailable: un, data: { health: dH, share, sites, stale },
      tasks: { health: tasksH, share: tShare }, compute: { health: cH, rate, gears, disabled, queueSlow }, steps: stepsShown, attention: att, options: o };
  }

  window.PSD = { buildFacts, assess, DEFAULTS, SEV, worstOf, natural, quantile, TOP_N };
})();
